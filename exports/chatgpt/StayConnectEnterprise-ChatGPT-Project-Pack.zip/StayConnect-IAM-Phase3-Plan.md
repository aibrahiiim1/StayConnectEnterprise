# StayConnect IAM — Phase 3 Plan (PMS Stay Domain, STRICT Multi-PMS Resolution, Room Movement, Checkout Grace, Reinstatement)

> Machine sentinel (governance): `PHASE_3_PRODUCTION_RUNTIME: DARK`
> `PHASE_3_NO_FINANCIAL_POSTING: TRUE` · `PHASE_3_LIVE_PMS: READ_ONLY` · `PHASE_3_TEST_PERSISTENCE: DISPOSABLE_DB_ONLY`

**Authorization:** Product-Owner decision **D14**, start transition **T0015** (2026-07-18). Base master HEAD `ffb68e1ad325f5dd6d2096f2e30a782f8caef059`. Branch `phase/3-stay-resolution-grace`, PR #6 → `master`. One end-to-end Phase; **not** split into separately-approved mini-phases. Delivered **DARK**: all Phase-3 flags default OFF; PR #6 is not merged before the single final Product-Owner acceptance decision.

This plan governs implementation, tests, live-dark deployment and rollback. It is synchronized with the Phase-0 Contract (`docs/architecture/StayConnect-IAM-Phase0-Contract.md`, §1, §2, §3 ERD, §4 canonical DDL, §5–§8, §9 FIAS) and the accepted Phase-1A/1B/2 baselines. Where the Contract is the design authority and the as-built schema/code differs, the **as-built reconciliation** (§2 below) governs the smallest additive delta.

---

## 0. Scope and non-scope

**In scope (D14):** PMS Interfaces + immutable Revisions + secret generations + validated guest-network routing; the Stay domain (Stays, Sharers, Folios as non-financial identity, PMS events, Room Move, Checkout, Reinstatement, source-conflict detection, freshness); STRICT automatic multi-PMS resolution; one-time PMS Auth Context issuance; Phase-2 Commerce integration in **test mode** (enable the capability-disabled Stay-based eligibility rule types); mandatory Checkout Grace + emergency fallback; Reinstatement episodes; Guest Portal PMS auth UI; Hotel Admin PMS/Routing/Stays/Events/Folios/Resolution UI; automated tests (D1–D11, F1–F7, concurrency, redaction/RBAC/step-up); a dedicated read-only PMS connector runtime; controlled live **read-only** PMS protocol verification; controlled live-dark deployment + one final reboot; evidence, governance and one final acceptance report.

**Explicitly NOT in scope (fail-closed, governance-enforced):** any PMS **financial posting** or FIAS `PS` transaction; Posting Engine / posting outbox / posting workers / `P#` allocation / charge retry / financial `UNKNOWN` handling; payments / Stripe / refunds / programmatic reversal / settlement execution; guest **paid** access; IAM-v2 production authentication **cutover** or any production iam_v2 runtime read/write; data migration into iam_v2; dual read/write; legacy IAM removal; **Phase 4** (financial posting), **Phase 5** (Post-Stay PIN, Cross-PMS transfer execution — F8/F9), **Phase 6** (device self-service); Central Control Plane changes; WAN/LAN/VLAN/DHCP/HA/topology changes.

**Folios** are ingested and managed as Stay-domain identity records only; they never create a financial command in Phase 3. There is no executable `PS` sender, dormant financial worker, or hidden Posting path anywhere in the Phase-3 deliverable.

---

## 1. AS-BUILT STATUS (governance)

> The original approved requirements below (§0 onward) are unchanged — this section records what has been
> BUILT against them, not a change to them.

`PHASE-3 PRE-LIVE SAFETY CANDIDATE COMPLETE — LIVE INCREMENT-9 AUTHORIZATION REQUESTED (D14 authorized / T0015; D15 Option C executed; software candidate T0016; pre-live safety closure T0017), DARK. Not accepted, not closed.`

The software increments in this plan are **execution history**, not future work:

- **Migration 0010**, the pmsd connector runtime, the Stay/Event/Folio engine, the STRICT multi-PMS resolver,
  PMS Auth Context, Phase-2 Commerce integration, Checkout Grace + emergency fallback, and Reinstatement —
  **built and tested** against disposable PostgreSQL 16.
- **Option C (D15)** — the Hotel-Admin scope-amendment proposal was **rejected with no scope reduction**; all
  eight operator surfaces and the accounting/netd/scd/portal corrections were completed.
- The **mixed Phase-2 direct-Entitlement writer is eliminated**, and the controlled-writer boundary now covers
  every authoritative Phase-3 family.
- **Accountable-before-forwarding** class provisioning is in force: netd stages prepare → register origin →
  activate, so no managed class forwards before its counter series has a durable accounting origin.
- **The enforcement architecture is nft + tc + Session, not tc alone.** This is the material change to the
  plan as originally written, and the older "accountable TC" wording no longer describes what is built:
  - `netd` is the single privileged **network-enforcement** owner, holding both kernel halves. `nft` decides
    packet authorization; `tc` decides accountable metering; `iam_v2.sessions.state` is durable runtime state.
    Removing a tc classification filter denies **nothing** — those packets fall back to the bridge's default
    class and keep flowing, unmetered.
  - Phase 3 authorizes in the structurally separate `phase3_auth_ipv4`; legacy `auth_ipv4` is unreachable from
    every Phase-3 code path.
  - Admission order: allocate generation → prepare tc without filters → register the accounting origin →
    activate filters → verify → **authorize** → verify → persist → prove the Session durably `active`.
  - Fail-closed means **nft denial first, proven**, then tc. Teardown and expiry use the same order.
- **Packet authorization is a bounded, renewable kernel lease** (90s, clamped by the session's hard access
  boundary; 15s while durable `active` is unproven). A healthy reconciliation renews it; silence expires it.
  If acctd and netd both die and nothing recovers, every Phase-3 guest loses access within the documented
  bound — because the kernel enforces it with nothing running.
- **"ACTIVE means authorized AND accountable" is a database invariant.** `activate_session_enforcement`
  verifies the accounting checkpoint itself — session, device, bridge, class minor and exact generation —
  before it will promote a Session, and refuses a fabricated, foreign, stale or contested origin.
- An activation whose durable outcome **cannot be proven** holds only the provisional lease and is then failed
  closed and quarantined with a doubling backoff. It can never become permanent Internet access.
- A **surgical live-dark nft foundation** (`cmd/phase3-foundation`) installs the Phase-3 set and rules into a
  running ruleset in one nft transaction, proving legacy-authorization parity on both sides and rolling itself
  back if it cannot. The cutover becomes flag-only **only after that install is performed and verified on the
  unit** — not on the strength of the software alone.
- One **true full same-HEAD software gate** (`phase3-full-software-gate`) is green, with a downloadable,
  independently-verified evidence artifact — now including a **real-kernel contract suite** that runs the real
  `nft` and `tc` binaries with real packets in disposable Linux network namespaces. That suite is kernel
  evidence produced on a disposable CI machine; it is **not** live appliance evidence.

**Still PENDING (requires a separate Product-Owner decision — see `governance/project-state.json`
`next_authorized_action`):** Live Increment 9 — read-only live PMS verification, controlled live-dark
deployment of the exact delivery HEAD, one reboot with post-reboot convergence, a rollback rehearsal, and
flags-OFF confirmation on the running unit. Until that decision: PR #6 stays open and unmerged, all Phase-3
flags OFF, migration 0010 undeployed, zero runtime `iam_v2` privileges, no appliance/Production/live-PMS
contact, no PS/PA, no financial posting, no Phase 4.

---

## 2. As-built reconciliation (audit result — governs the additive delta)

A read-only audit (schema + PMS code + reuse patterns) established the following authoritative facts:

**2.1 Schema — all 18 Phase-3 tables already exist** in the canonical iam_v2 schema (`iam_v2_scratch/migrations/mg1..mg9`):
`pms_interfaces`, `pms_interface_revisions` (immutable via mg9 `imm_pms_rev`), `pms_interface_secret_generations` (mg9 `sg_guard`: identity immutable, only `superseded_at` mutable), `guest_network_pms_map` (partial-unique one-default), `pms_source_conflicts` (CHECK a<b), `stays` (mg4), `stay_guests` (partial-unique one-primary), `folios` (partial-unique open-identity), `stay_folios` (partial-unique default target), `stay_events` (UNIQUE external_event_identity; processing_status enum), `stay_links`, `auth_resolutions` (mg8), `auth_contexts` (mg5; method CHECK incl. `PMS`; pin checks; TTL), `purchases` (mg5; `checkout_episode` + partial-unique `one_conversion_per_episode`; Phase-2 `purchase_quote_pin_equal`), `entitlements` (mg6; 4 partial-unique one-live indexes; `ent_guard`), `entitlement_devices` (mg6; `reserve_device_slot()` advisory-lock capacity), `sessions` (mg6; idempotent `close_session()`), `site_checkout_grace_config` (mg2).

**2.2 Migration 0010 scope — the audited additive gaps** (`data-plane/migrations/0010_phase3_stay_resolution.up.sql` / `.down.sql`, additive + reversible, iam_v2_owner-owned, Tenant/Site/Interface composite FKs, public schema untouched). The exact per-object scope is proven by the machine-grounded gap audit (`docs/evidence/StayConnect-IAM-Phase3-Schema-Gap-Audit.md`) against a disposable PostgreSQL build; the design below is corrected per the Product-Owner directive:

1. **Connector-freshness / cursor persistence — FOUR INDEPENDENT AXES.** No PMS connector runtime state exists. Add a typed `pms_interface_runtime` (1 row per `(tenant,site,pms_interface_id)`, pinned current revision + runtime generation + updated_at) that preserves **four independent axes** — never collapsed into one authoritative field:
   - **Transport axis** — typed transport status, last connection attempt, last connected, last successful heartbeat/keepalive, disconnected-since, sanitized error code (never raw credentials/payload).
   - **Feed-continuity axis** — typed continuity status, last valid event received, last protocol sequence/cursor (where supported), discontinuity-detected time, last observed resync/night-audit marker.
   - **Complete-sync axis** — typed synchronization status, resync-requested/started, last successful complete sync, durable cursor/checkpoint, last sync-failure code.
   - **Occupancy axis** — occupancy freshness belongs to the exact Stay/source evidence, **not** globally to the Interface. Recorded per-Stay (see gap #4), **composite-FK-pinned** to the producing Interface Revision, all-or-none, `normalization_version>0`.
   **No stored `derived_freshness`** — the overall status is computed in the Phase-3 domain from the four axes + revision thresholds (an operator/connector cannot write `HEALTHY` while the axes contradict it). `pms_interface_runtime` carries structural constraints: `runtime_generation>=0`, CONNECTED requires **both** a pinned Interface Revision AND a pinned Secret Generation (composite-FK'd to the same tenant/site/interface — identity only, never key material), heartbeat ≤ updated_at, resync coherence, bounded error-code/cursor lengths. No unvalidated runtime JSON blob.
2. **One-way status + monotonic version enforcement** — trigger(s) forbidding illegal/backward `stays.status` transitions and enforcing monotonic `last_applied_event_version` and `lifecycle_version`; normal runtime roles cannot arbitrarily update status / lifecycle_version / last_applied_event_version / effective_checkout_at. State changes flow only through one controlled apply function (§4/§17 of this plan).
3. **Checkout episode = `stays.lifecycle_version` (NO new counter).** The authoritative lifecycle episode is `stays.lifecycle_version` (initial episode = current value; duplicate checkouts in one lifecycle reuse it; Reinstatement increments it exactly once; the next checkout uses the new value). `purchases.checkout_episode` is **populated from the locked Stay's `lifecycle_version`**, so the existing `purchases.one_conversion_per_episode` partial-unique key is `(stay_id, lifecycle_version)`. Migration 0010 adds **no** `stays.checkout_episode` column — there must not be two independently mutable episode counters. (A separate Stay episode column would require a focused ADR + tests proving the two values can never diverge; the gap audit shows it is unnecessary.)
4. **Effective-checkout + per-Stay occupancy evidence** — add `effective_checkout_at timestamptz` on `stays` (the accounting boundary) and the smallest typed per-Stay occupancy-evidence fields the gap audit proves missing (source-evidence timestamp, ingestion timestamp, pinned revision, normalization version, clock-suspect), composite-FK-pinned to the same Interface's producing revision (historical revisions preserved), all-or-none; plus typed grace scalar columns on `site_checkout_grace_config`: `eligibility_window_seconds` (default 86400), `grace_duration_seconds`, `grace_down_kbps`, `grace_up_kbps`, **`grace_data_quota_bytes bigint`** (BYTES are the authoritative unit; UI converts MB/GB for display only), `grace_device_limit`, and `grace_device_limit_policy` reusing the **canonical** `service_plan_revisions.device_limit_policy` vocabulary `('REJECT_NEW_DEVICE','DISCONNECT_OLDEST','ADMIN_APPROVAL')` — validated bounds via `grace_bounds`. The typed columns are the authoritative grace policy; the pre-existing `config jsonb` is NOT a second source of truth for duration/rates/quota/device-limit/policy/eligibility.
5. **`auth_resolutions` server-side resolution-request idempotency key** — add a `resolution_request_id` (opaque, Tenant/Site-scoped unique); Phase-3 resolver writes must supply it (replay returns the existing outcome); a nullable column is allowed for backward compatibility but Phase-3 writes never silently omit it. Outcome codes only; no guest-credential values.
6. **`stay_events` append-only guard** — trigger making the immutable identity/normalization columns append-only (Tenant/Site/Interface identity, revision, external_event_identity, event_type, raw/normalized timestamps, normalization_version, sanitized payload identity/hash, clock-suspect), allowing only the approved application-result fields to change (processing_status through its one-way terminal state machine, resolved stay_id, processed timestamp, sanitized failure/review code); no arbitrary row replacement.

Migration 0010 creates `pms_interface_runtime` plus — as directed by the Product-Owner Checkout-hardening corrections — a small set of **append-only integrity tables** that make the atomic Checkout conversion provable rather than inferred: `checkout_grace_audit` (durable one-per-episode conversion evidence + boundary provenance), `checkout_grace_alert_actions` (the resolvable OPEN/ACKNOWLEDGED/RESOLVED operational-alert lifecycle over that evidence), `entitlement_state_transitions` (the controlled Entitlement state-machine history that proves state AT a past boundary), and `entitlement_device_authorizations` (append-only device-authorization intervals that prove which devices were authorized AT the boundary). These exist because a Checkout must prove eligibility/device-cohort/quota/config **at the effective-checkout boundary** from immutable history, not from a mutable current row. It does not recreate/rename any canonical table; all other Phase-3 needs are satisfied by existing tables. **No public business/IAM table or public-schema business structure is changed; the only public-schema write is the expected `schema_migrations` metadata row.** (Ledger bootstrap, if ever required, is a separate acknowledged administrative operation — never part of a normal Migration 0010 run.) No Production Stay/Guest/Folio rows during dark deployment. No fake seed data. Objects owned by `iam_v2_owner`; zero runtime grants while dark; `SECURITY DEFINER` avoided unless technically necessary (then fixed `search_path`, owner-only, `EXECUTE` revoked from `PUBLIC`, no dynamic SQL on untrusted identifiers).

**2.3 PMS connector — proven code exists but is mis-owned.** `data-plane/internal/pms/protel_fias.go` (472 lines) is a working FIAS TCP client (STX/ETX framing; `LS/LD/LR` handshake in `recordLS/recordLD/recordLRs`; `GI/GC/GO/LA/LE` in `handleRecord`; `DR` resync; in-memory room cache; `runLoop`/`connectAndServe` reconnect). But the long-lived socket is owned by **scd** (the guest-facing session daemon) via the provider goroutine (`main.go:622` boot → `pmsloader.StartAll`), with **no cross-process single-owner lock**. This violates §9 (no long-lived PMS socket inside a guest daemon; one dedicated owner per interface with a single-owner lock). See ADR-0001 (§3).

**2.4 Reuse patterns (mirror exactly):** feature flags — `data-plane/internal/iamv2/commerce_config.go` (env-only, master/child, `Validate()` fail-closed, nil-repo-when-dark, engine short-circuits with zero SQL); Commerce Phase-3 seam — `commerce_domain.go` already recognizes `STAY_STATUS/STAY_LENGTH/ROOM_TYPE/VIP/TRAVEL_AGENT/PMS_INTERFACE/RATE_PLAN` but capability-disabled (`IsCapabilityDisabledRuleType`), `AuthContextRow.StayID` exists but required empty in P2; Admin — `edged` `mountResource`/`resourcePermission`, `rolePerms` (auth.go), `reauth` step-up, `audit` sink; portald bridge — opaque `sc_commerce` cookie, server-derived pins; throttle — `internal/throttle` + `auth_throttle_buckets` (`method="pms"` already allowed; per-interface needs a new scope kind or identity-encoding); tests — `PHASE2_TEST_DSN` disposable-DB pattern, Vitest + Playwright configs under `hotel-admin/`.

---

## 3. Architecture Decision — ADR-0001: dedicated `pmsd` connector daemon

**Context.** §9 requires: long-lived PMS sockets not owned by guest HTTP handlers; one dedicated local connector owner per PMS Interface; one independent worker/state-machine per Interface; failure isolation between Interfaces; local-first (no cloud dependency for auth/events/grace); ownership survives restart; exactly one client owns a PMS Interface connection at a time. The proven FIAS protocol code exists but is embedded in scd with no single-owner lock (§2.3).

**Decision.** Introduce a dedicated local daemon **`data-plane/cmd/pmsd`** that owns each PMS Interface connection. pmsd:
- reuses the proven protocol layer (`data-plane/internal/pms`) — it does **not** create a second FIAS stack;
- runs one independent supervised worker/state-machine per Interface (bounded exponential reconnect backoff; deterministic connection state; SIGTERM drain; restart/reboot recovery);
- acquires a **DB advisory single-owner lock per (tenant,site,pms_interface_id)** before opening a socket; a competing owner is rejected (satisfies "exactly one client owns the Interface"); the FIAS spike's orphan-slot reap is honored at start;
- persists connector freshness/cursor to `pms_interface_runtime` (§2.2.1) so scd/edged/portald read freshness from the DB rather than owning sockets;
- pins the current Interface Revision + secret generation when opening a connection; never logs credential material; redacts record framing payload before persistence/evidence;
- generates **no financial record** and contains **no `PS` sender**;
- is gated by `STAYCONNECT_PHASE3_PMS_CONNECTOR` (child of `STAYCONNECT_PHASE3_MASTER`); OFF ⇒ no socket opened at all.

A new systemd unit `deploy/systemd/stayconnect-pmsd.service` runs it. scd's existing embedded FIAS ownership remains the **legacy** production path (unchanged, still authoritative today); the Phase-3 pmsd path is DARK and separate until a future cutover. **Rejected alternative:** extending scd to also own a second connector — rejected because scd is a guest-facing HTTP/unix-socket daemon and §9 forbids the long-running PMS socket living there.

Full ADR: `docs/architecture/adr/ADR-0001-pmsd-connector-ownership.md`.

---

## 4. Feature flags (all default OFF, fail-closed)

Deployment-controlled local env/config flags mirroring `commerce_config.go`, in a new `data-plane/internal/iamv2/pms_config.go`:
`STAYCONNECT_PHASE3_MASTER`, `STAYCONNECT_PHASE3_PMS_CONNECTOR`, `STAYCONNECT_PHASE3_PMS_INGEST`, `STAYCONNECT_PHASE3_PMS_AUTH`, `STAYCONNECT_PHASE3_CHECKOUT_GRACE`, `STAYCONNECT_PHASE3_ADMIN`, and the browser admin gate `NEXT_PUBLIC_PHASE3_ADMIN` (mirroring the actual Phase-2 admin gating — server-side + Next routing/middleware; a `NEXT_PUBLIC_*` constant only if the Phase-2 convention adopts one). Rules: malformed values fail closed; a child cannot be ON while master is OFF (`Validate()`); Production defaults OFF; no DB feature-toggle UI. **OFF means:** no PMS connection, no Phase-3 repository construction, zero Phase-3 SQL, no PMS event ingestion, no Phase-3 auth routes, no Grace execution, no UI surface, no runtime iam_v2 grants. The live read-only PMS **acceptance harness** is separate from production service flags and guarded by: explicit test acknowledgement, target allowlist, single-owner check, disposable-DB marker, and a hard prohibition of financial record types.

---

## 5. Migration 0010 (see §2.2). One coherent additive chain after `0009`. Tested apply / apply-twice / down / reapply / catalog-fingerprint reproducibility. No Production data migration; **the only public-schema write is the expected `schema_migrations` metadata row (no public business/IAM structure changed)**; no seed rows.

## 6. PMS connector runtime (pmsd) — read-only. Preserve only verified FIAS behavior (spike §9/Gate-3A): `LS→LD→LR→LA`; ack incoming `LS`/`LA` with `LA|`; ingest `GI/GC/GO`; read-only `DR` resync (`DS`…`DE`); exact framing; never invent unsupported records; no `PS`. One active owner per Interface (DB advisory lock); bounded reconnect; keepalive/heartbeat observation; durable sync cursor; source timezone from the pinned Revision; credential material never logged; payload redacted before persistence; bounded queues; SIGTERM drain; restart/reboot recovery.

## 7. PMS Interface + Revision domain. Typed immutable Revisions (connector kind, source timezone, normalization version, source fingerprint, endpoint/transport, read-only auth capability, verifier combinations, field normalization, max auth-cache age, connector timeouts, heartbeat/freshness thresholds, resync/night-audit markers, folio identity strategy, measured capabilities). Publication rejects unknown keys; append-only; atomic current-revision pointer (same Interface, Tenant/Site scoped); a revision that removes the verifier intersection required by an existing mapping fails publication/activation, leaves the previous current, alerts, and fails auth closed.

## 8. Secret generations (write-only AEAD; generation number; no plaintext read/redisplay; password step-up for rotation; immutable ciphertext/nonce/key; controlled `superseded_at`; zero credentials in logs/exports). Phase-3 uses the active generation for read-only connectivity only.

## 9. Guest-network routing (`guest_network_pms_map`): no rows ⇒ PMS auth unavailable + `pms_config_missing` alert + fail-closed; `MAPPED` = mapped ACTIVE interfaces; `ALL_ACTIVE_INTERFACES` explicit; candidate default max 3, hard cap 5 (enforced at save + runtime); every candidate exposes ≥1 common determinate verifier combination; Guest-Network/Interface/mapping same Tenant/Site; client hints discarded; `is_default` never bypasses STRICT.

## 10. Durable freshness — FOUR INDEPENDENT AXES (`pms_interface_runtime` for interface-level transport/feed/sync; per-Stay occupancy evidence on `stays`, composite-FK-pinned to the producing revision). The model preserves independently (1) transport/heartbeat health, (2) feed-continuity health, (3) last-complete-synchronization/resync health, and (4) occupancy-evidence freshness for the exact Stay evidence used by authentication. **No stored `derived_freshness` field** — the overall availability/freshness (HEALTHY/UNAVAILABLE/STALE/DEGRADED_FRESHNESS/RESYNC_REQUIRED/UNSUPPORTED_EVIDENCE) is **computed in the Phase-3 domain** from the four axes + the thresholds pinned in the Interface Revision, so an operator/connector can never write `HEALTHY` while the underlying axes contradict it. Continuity comes from protocol evidence + resync/night-audit markers, not "no event for N minutes". Authentication returns VERIFIED only when the exact per-Stay occupancy evidence satisfies the current Revision's auth freshness bound; a cache older than `max_auth_cache_age` is STALE, never VERIFIED. All axes persist to survive restart/reboot.

## 11. Stay lifecycle engine. Canonical states RESERVED/IN_HOUSE/CHECKED_OUT/POST_STAY_ACTIVE/CANCELLED/NO_SHOW. Room Number is lookup evidence only, scoped by Interface, never identity, deliberately no one-Stay-per-room uniqueness; sharers legal; external Stay identity pinned to one Interface; stale/out-of-order events retained but cannot corrupt current state (`last_applied_event_version` monotonic); trusted reinstatement `lifecycle_version++`; DUE_IN/DUE_OUT are UI-derived. Global lock order **L1 Stay → L2 Subject/Credential → L3 Entitlement → L4 Capacity → L5 Configuration**, never backwards.

## 12. Sharers / primary guest (independent identities; ≤1 primary per Stay; primary change demotes+promotes in one tx; duplicate reassertion = SKIPPED_DUPLICATE; materially conflicting = MANUAL_REVIEW; deterministic revisioned name normalization; Room Number is never identity).

## 13. Folio identity — non-financial (strategies GLOBALLY_UNIQUE/UNIQUE_PER_STAY/REUSED_SEQUENTIAL/UNSET; UNSET allows read-only ingestion/lookup/auth but is financially fail-closed; open folio unique within Interface; reused-sequential creates a new row `identity_epoch+1`; historical rows never repointed; Stay↔Folio links Interface-scoped; ≤1 default posting target per Stay; auth does not select/pin a Folio; no Posting record created).

## 14. Room Move (same Stay identity + subject; no new Stay/Entitlement/quota-reset/validity-reset/Purchase-consume/device-disconnect/nft-recreate/Cross-PMS-transfer; update only verified room lookup + event history; preserve entitlement, devices, sessions, consumed data/time, original Purchase, lifecycle version).

## 15. STRICT resolver (the only mode). Candidate outcomes VERIFIED/AMBIGUOUS_LOCAL/NO_MATCH/UNAVAILABLE/STALE/UNSUPPORTED_EVIDENCE. Derive candidates from the trusted Guest Network; ignore client hints; pin each candidate's current Revision; fan out in parallel with revision-specific bounded timeouts; wait for the complete vector (never first-success, never fastest). Success iff exactly one VERIFIED + all others determinate NO_MATCH. Any UNAVAILABLE/STALE/UNSUPPORTED ⇒ INDETERMINATE fail-closed. ≥2 VERIFIED or any AMBIGUOUS_LOCAL ⇒ discriminator escalation. No fallback, even single-candidate. Guest sees no PMS/property/interface/candidate/failure detail; all non-success responses byte-equivalent + fixed time budget; internal reason codes to audit/metrics only. Layered throttling (room+IP, room+MAC, per-interface, site/global) via the durable `internal/throttle` foundation.

## 16. PMS Auth Context (one-time; pins Tenant/Site/Interface/Revision/Stay/StayGuest?/Device/GuestNetwork/method/evidence-version/created/expiry/consumed; immutable except one-time consume; short-lived; unusable after checkout/staleness or across Tenant/Site/Interface/Device/Network; consumed atomically with Quote/Purchase; a context without a Stay is rejected; no Folio selected at auth; **not** a Session — sessions only after Entitlement grant).

## 17. Phase-2 Commerce integration (test mode). Enable the capability-disabled Stay-based rule types (STAY_LENGTH/VIP/ROOM_TYPE/TRAVEL_AGENT/PMS_INTERFACE/arrival-departure/RATE_PLAN/PRIOR_PURCHASE) by populating `EligibilitySubject` with authoritative Stay fields from the pinned Auth Context; unknown/absent Stay evidence fails closed; current Stay changes after Quote creation do not rewrite the Quote; matched rule/tier evidence snapshotted; no client-supplied Stay/Interface/grant/package-revision. Full disposable flow tested: `PMS credentials → STRICT resolver → one-time Auth Context → eligible Package list → Quote → FREE Purchase → Settlement NOT_REQUIRED → Stay Entitlement → Session`; once-per-Stay purchase uniqueness under concurrent confirmation. Production stays DARK.

## 18. Checkout (one atomic tx, lock order L1→L4): lock Stay → verify pinned Interface + lifecycle episode → apply effective checkout timestamp → status CHECKED_OUT + `posting_allowed=false` → terminate current Stay Entitlement (CHECKOUT) → determine Grace eligibility → exactly one Grace Purchase per episode when eligible → Grace Entitlement → supersede prior atomically → copy/rebind authorized devices → rebind sessions with zero nft churn → shaping to Grace policy → grandfather devices above the Grace limit → commit once. Any pre-commit failure rolls back fully; no partial states.

## 19. Grace eligibility (AUTHORITATIVE PO rule): the Stay has an **active valid Stay Entitlement at `effective_checkout_at`** — regardless of the prior package's origin or price (FREE / PAID / Stay-based / any other approved source; origin never affects eligibility). Recent device activity is **not** the eligibility test. A never-authenticated Guest with no Entitlement at checkout ⇒ checkout completes, no new Grace. Exactly **one** Grace conversion per lifecycle episode (deterministic boundary; idempotent under duplicate/concurrent checkout). `grace_duration_seconds` is the Grace Entitlement **lifetime** from the boundary, not the eligibility test. `eligibility_window_seconds` has a **secondary** purpose only — the broad window within which **Stay-based Commerce eligibility rules** still apply after the boundary; it never excludes a Guest who has an active Entitlement at checkout and never overrides this rule. Grace Package revalidated every checkout (active, hidden/system, type CHECKOUT_GRACE, current revision valid, pinned plan revision enabled, price 0, settlement exactly `{NOT_REQUIRED}`, supported duration policy, same Tenant/Site).

## 20. Emergency Grace fallback (config invalid at checkout ⇒ built-in versioned policy 60min / 5↓ 2↑ Mbps / 500MB / reject-new + grandfather; Purchase trigger EMERGENCY_GRACE; `is_emergency_grace=true`; Grace Entitlement; `CHECKOUT_GRACE_CONFIG_INVALID` critical alert; immutable audit; never a skip/outage). Built-in policy, not a fake DB package.

## 21. Device/Session rebinding (no logout/re-auth/redirect/nft churn; session row re-pointed to the new Entitlement atomically; tc to Grace values; accounting idempotent; pre-checkout quota historical; Grace counters from the effective-checkout boundary; every device authorized AT the boundary is grandfathered — kept even above the configured limit, never disconnected; EVERY device NOT authorized at the boundary is a new device and is rejected for the whole Grace lifetime under `REJECT_NEW_DEVICE` — being below `grace_device_limit` does NOT admit a new post-checkout device).

## 22. Effective-checkout timestamp + delayed events (trusted normalized PMS timestamp when clock/freshness-valid; idempotent accounting split around the boundary; no usage loss/double-count/negative; no reopening terminated entitlements; no moving an immutable validity window; late samples ledgered, duplicates idempotent; clock-suspect ⇒ mark + documented conservative policy + audit, never fabricate).

## 23. Duplicate checkout + episodes (uniqueness = one conversion per Stay+lifecycle_version; repeated checkout same episode = idempotent no-op; concurrent = one Grace Purchase; Reinstatement only from CHECKED_OUT via trusted event/privileged action, `lifecycle_version++`, → IN_HOUSE, posting re-evaluated never blanket-restored, prior episode history untouched; post-reinstatement checkout is a new episode = one new conversion). No Post-Stay PIN in Phase 3.

## 24. PMS source conflicts (identical fingerprint / duplicate endpoint / sustained cross-interface identity collisions; ordered pairs once; INFO/WARN/CRITICAL; alert + fail-closed where unsafe; never leak conflicting interface to guests). No Phase-4 financial approval/posting controls.

## 25. Hotel Admin APIs (`/edge/v1`, `mountResource`+RBAC+audit+optimistic concurrency; password step-up for secret rotation / Interface disablement / Reinstatement / destructive lifecycle / forced resync): PMS Interfaces (+immutable Revisions, publish, timezone, verifier combos, freshness, fingerprint, connector status, write-only secret rotation, active/auth-disabled, safe resync); Guest-network routing (validated mappings, mode, shared-evidence intersection, candidate-limit, broken-mapping alert); Stays (guests/sharers/folios/timeline/room-move history/lifecycle version/freshness, read-only entitlement/purchase association, privileged Reinstatement, admin posting-block fields only, no financial action); Resolution inspection (outcome counts, interface health, config errors, uniform outcome code, no credential/PII payload). No arbitrary secret values or raw PMS payloads exposed.

## 26. Hotel Admin UI (Next.js, typed forms not raw JSON, hidden while `NEXT_PUBLIC_PHASE3_ADMIN` OFF): PMS Interfaces / Revisions / Credentials-Rotation / Guest-Network Routing / Connector Health / Sync-Backlog / Stays / Stay-Guests-Sharers / Folios / Event Timeline / Auth Resolution Audit / Source Conflicts / Checkout Grace status. Immutable/published badges, no secret redisplay, timezone selector, verifier-combo editor, candidate-intersection preview, mapping validation, real freshness indicators (explicit STALE/UNAVAILABLE/RESYNC_REQUIRED, no fake "healthy"), PII masking, pagination/filters, RBAC-aware nav, disabled/DARK state, step-up dialogs.

## 27. Guest Portal PMS UI (behind the Portal flag; normal room/guest credential fields; generic additional-verification prompt only when required; no PMS selector/labels/failure reason). portald derives Tenant/Site/GuestNetwork/Device/IP/session server-side; the browser submits only the allowed normal credential fields (never Interface/Revision/Stay/StayGuest/Tenant/Site/GuestNetwork/Device IDs or freshness/outcome). Success ⇒ opaque Auth Context → Phase-2 package selection (no Session before Purchase/Entitlement); non-success ⇒ uniform generic response (no room-exists/interface disclosure).

## 28. Roles (`site_admin` full; `hotel_it_manager` interface/routing/health, no financial; `front_office_operator` Stay/Folio/Event read + guest assistance + privileged Reinstatement with step-up, no connector credentials; `site_viewer` read-only sanitized). Secret rotation never allowed to read-only roles. Every privileged action audited (actor/tenant-site/resource/action/timestamp/reason?/result; no secret or guest-credential values).

## 29. Tests. **D1–D11** (namespace independence; ambiguity+discriminator; slow-VERIFIED beats fast-NO_MATCH; any UNAVAILABLE/STALE/UNSUPPORTED fail-closed; unmapped fail-closed; candidate cap save+runtime; forged hints ignored; verifier-intersection publish rule; sharers/primary; stale-cache/checked-out refusal — Phase-4 financial part of D10 excluded; uniform-response + throttle + reason-code audit). **F1–F7** (Room Move preservation; stale-event no-op; origin-agnostic checkout conversion incl. isolated paid/prepaid **fixtures** clearly not live payment evidence; grandfathering; eligibility window; emergency fallback; episode idempotency). **F8/F9 NOT implemented/claimed** (Phase 5). Plus cross-tenant/site/interface FK fuzzing, event races/replay, connector restart, appliance reboot, interface-outage isolation, slow/unavailable interface, resync-after-missed-checkout, delayed checkout, clock-suspect, primary-change race, move/checkout race, checkout/session-close/accounting race, ≥24 concurrent checkout handlers, ≥24 concurrent resolutions, one-live-entitlement, once-per-Stay concurrency, secret-rotation redaction, no-credentials-in-logs, no-PII-in-`auth_resolutions`, flags-OFF zero-SQL / zero-PMS-connections, UI component + Guest-Portal E2E + Hotel-Admin E2E, RBAC/audit/step-up, migration apply/twice/down/reapply, clean shutdown/restart, offline Control-Plane operation, disposable-infra teardown.

## 30. Controlled live read-only PMS acceptance (after the software gate). Only configured Interfaces; verify Interface identity before connecting; respect the one-client slot + single-owner lock; no competing client; **no `PS`**; persist only to an isolated disposable Phase-3 DB; sanitize all evidence (remove Room/Guest/Reservation/Folio identifiers); use controlled test reservations where available; record real transport/startup/event/resync/lookup evidence; prove two-interface isolation; prove read-only Interface 2 (Aqua Club / Hotel ID 2, financially unapproved) usable for Stay/Auth testing regardless of its separate financial state; destroy the disposable DB + harness after the gate. Distinguish **live protocol evidence** vs **sanitized captured replay** vs **synthetic isolated unit fixtures**; only live protocol evidence supports a claim about actual PMS wire behavior. If real data lacks a duplicate-room/sharer/move/checkout/reinstatement scenario, use a controlled test reservation, a verified sanitized replay, or a live supervised event — never invent a claim.

## 31. Software gate (before live-dark): `go build/vet/test ./...`, gofmt, `tsc`, frontend unit/component, Guest-Portal E2E, Hotel-Admin E2E, production frontend build, DB integration, migration lifecycle, connector protocol contract tests, D1–D11, F1–F7, security/redaction, RBAC/audit/step-up, flags-OFF. Record exact commands/timestamps/exit codes/environment/source HEAD/lockfiles/artifact hashes/test totals/genuine failures+fixes. Governance CI is not a substitute.

## 32. Live-dark deployment (after the gate): destroy disposable infra; confirm clean tree; build pinned Linux artifacts for changed components only + record SHA-256; reverify appliance identity; fresh pre-Phase-3 backup; record pre-deploy schema fingerprints/rows; apply additive 0010 as iam_v2_owner; confirm iam_v2 free of Production Stay/Guest/Folio/Event/Auth-Context rows; zero runtime iam_v2 DML grants while flags OFF; deploy changed artifacts; install/update `stayconnect-pmsd.service`; confirm all Phase-3 flags absent/OFF; confirm no PMS socket / no Phase-3 repo / zero Phase-3 SQL / no PMS-event rows / no Stay-Folio-AuthContext rows / no Phase-3 routes-UI / existing runtime healthy; restart only affected services; smoke checks; **one final full reboot**; repeat all darkness checks post-reboot. Do not enable Phase 3; do not cut over IAM-v2.

## 33. Rollback (prepared + verified): 0010 down scripts; prior binaries; prior UI release; systemd units; env files; pmsd service; flags; DB backup. DARK ⇒ runtime rollback = flags OFF + restore prior artifacts; DB rollback = tested additive down; no Production Phase-3 data to reverse. Rollback only on a real deployment failure, never merely because acceptance is pending.

## 34. Documentation + evidence: this Plan; `Phase3-Privilege-Matrix.md`; ADR-0001 (+ any further ADRs); Phase-3 software-gate evidence; live read-only PMS evidence; live-dark deployment evidence; acceptance candidate; final 20-section report; complete change manifest; decision register; transitions; project state; Handoff; START-HERE; operations manual; deployment/migration/offline runbooks; PMS support runbook; Project Pack + Phase Evidence Pack; checksums/provenance. Evidence distinguishes synthetic fixtures / sanitized replay / real live read-only / live-dark deployment; no live-verified claim is made where only a unit fixture was used. Development-environment reporting language per §7 of the authorization (exact technical effect; no "no guest impact" boilerplate without verified live guest use).

## 35. Governance guards (§45 of the authorization): Phase 3 cannot be IN_PROGRESS without D14/T0015; Phase 2 stays closed; Phase 4 unauthorized; no Posting scope / no `PS` sender / F8/F9 not claimed / no guest PMS selector; Phase-3 flags default OFF; no runtime iam_v2 grants; no Production Phase-3 rows while dark; final manifest equals Git; current plan/evidence in Project + Evidence Packs; no stale "Phase 3 not authorized" wording after D14/T0015; no stale "continue Phase 2" wording; no live-guest-impact claim without verified live use; read-only PMS acceptance never labeled financial acceptance. Structural guards + adversarial mutations; baseline clean after every injected mutation.

---

## 36. Increment plan (§46 environment-boundary protocol)

Each increment is one coherent, committed, pushed, CI-green step on `phase/3-stay-resolution-grace` (PR #6), reporting the exact next workstream.

- **Increment 1 (this delivery):** governance (D14/T0015, project-state → IN_PROGRESS) + this Plan + Privilege Matrix + ADR-0001 + Phase-3 governance guards/mutations + branch/PR.
- **Increment 2:** migration `0010_phase3_stay_resolution` (up/down) + `pms_config.go` flags + migration lifecycle tests.
- **Increment 3:** `pmsd` daemon skeleton + single-owner lock + freshness persistence + protocol reuse + connector contract tests (flags OFF; no live connection).
- **Increment 4:** Stay/Event/Folio engine (lifecycle, sharers, room move, event idempotency) + concurrency tests.
- **Increment 5:** STRICT resolver + PMS Auth Context + throttle wiring + D1–D11.
- **Increment 6:** Checkout Grace + emergency fallback + Reinstatement + device/session rebinding + F1–F7.
- **Increment 7:** Phase-2 Commerce integration (enable Stay rule types) + disposable end-to-end flow tests.
- **Increment 8:** Hotel Admin API + UI; Guest Portal PMS UI; component + E2E tests; RBAC/audit/step-up.
- **Increment 9:** full software gate; live read-only PMS acceptance (REQUIRED FROM PRODUCT OWNER: test reservation + appliance access); live-dark deployment + reboot; evidence; final acceptance report.

The only final next action is one Product-Owner acceptance decision on Phase 3 at verified DARK maturity. No self-accept; no merge of PR #6; no Phase 4; no IAM-v2 cutover; no Phase-3 flag enablement; no financial PMS action.
