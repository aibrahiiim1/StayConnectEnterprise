# PERMANENT RULE — GitHub Execution, Reporting and Delivery (project-wide, mandatory)

**Authoritative, permanent Product-Owner operating rule for the remainder of the StayConnect Enterprise project.** It governs how every future Phase and milestone is executed, verified, reported and delivered through GitHub. It is a companion to, and does not replace, the [Zero-Stale-Leftovers rule](ZERO_STALE_LEFTOVERS_RULE.md) or the machine-readable project-state governance (`governance/project-state.json`, `tools/project-state.py`). Where this rule and the project-state governance overlap, both must pass.

<!-- MACHINE ASSERTION - validated by tools/project-state.py -->
`GIT_OPERATIONS_OWNER: AGENT`  (all Git and GitHub operations are performed by the authorized AI Agent; the Product Owner is never asked to run routine Git or `gh` commands — see §12)

## 0. Authoritative repository

- Repository: **`https://github.com/aibrahiiim1/StayConnectEnterprise.git`** (remote `aibrahiiim1/StayConnectEnterprise`).
- The GitHub repository is the **only** authoritative project source.
- Uploaded ZIP files (Project Pack / Evidence Pack / Planning Pack) are **exports and review artifacts only**. They must never silently override the repository state, Git history or verified execution evidence. When a ZIP and the repository disagree, the repository wins and the discrepancy is reported.

## 1. GitHub is the only authoritative working source

**Scope (Product-Owner decision).** The full preflight below is a **CONTROLLED-work** procedure — a migration, a deployment, an approved milestone or phase, an authoritative export, or an explicit release closure, per `CLAUDE.md` §0. Routine FAST DEVELOPMENT does not run it: for ordinary code, UI and bug work, use the current checkout, run only the relevant targeted tests, and commit locally. The repository is still the authoritative source and Git is still mandatory; what changes is that a routine edit no longer triggers a release preflight.

Before every CONTROLLED task, in order:

1. Fetch the remote repository (`git fetch origin`).
2. Verify the expected remote is `aibrahiiim1/StayConnectEnterprise`.
3. Verify the base branch and current HEAD (record both SHAs).
4. Ensure the full repository is clean (`git status --porcelain --untracked-files=all` is empty).
5. Run the project-state governance validator (`python tools/project-state.py validate` → `PROJECT_STATE_GOVERNANCE = PASS`) and the keyword layer (`tools/validate-project-state.sh` → `ZERO_STALE_LEFTOVERS = PASS`).
6. Read the authoritative project sources in their required precedence order (project-state governance → FINAL contract → synchronized handoff → current phase plan → verified evidence → system/ops docs).
7. Confirm the current Phase, authorization scope and the single next authorized action.

Do not work from an old ZIP, a copied folder or a stale local branch. Do not claim a commit exists until it is pushed and reachable from the GitHub remote.

## 2. One complete Phase per branch and PR

- Use **one implementation branch per approved Phase or major authorized milestone**.
- Use **one PR for the complete Phase**.
- Do not create unnecessary micro-branches, micro-PRs or extra Product-Owner prompts.
- Complete the full authorized Phase end-to-end inside that branch: implementation, migrations, tests, rollback, documentation, governance updates and exports in the **same** Phase delivery.
- **Never** continue automatically into the next Phase.

Recommended branch format: `phase/<phase-name>-<short-purpose>` — e.g. `phase/1b-dark-auth`, `phase/2-packages-quotes`, `phase/3-multipms-resolution`. Governance-only updates use `governance/<short-purpose>`.

Do not commit directly to the protected default branch unless the Product Owner explicitly authorizes that exact action.

## 3. No unnecessary stopping

A Phase authorization permits completing all work explicitly included in that Phase without stopping for minor internal decisions. **Do not stop** for: normal implementation choices already governed by the approved contract and Phase plan; routine file changes; tests and fixes inside the authorized Phase; documentation synchronization; export regeneration; ordinary refactoring required to complete acceptance.

**Stop only for a genuine hard blocker:** a contradiction with an authoritative Product-Owner decision; a missing prerequisite that cannot be safely created within the authorized scope; a security or financial risk; an action outside the authorized Phase; a production failure that cannot be safely rolled back; an acceptance failure requiring an architecture or contract decision; or a missing Product-Owner authorization for live traffic, cutover, financial posting or another separately-gated action.

When stopping, report **one precise blocker** and the recommended resolution. Do not restart the entire Phase.

## 4. Complete automatic changed-file manifest

Every final Agent report must include **every affected file without exception**, generated by `tools/generate-change-manifest.py` (never a hand-written list). The generator produces a deterministic manifest from the Phase base commit to HEAD using Git, and must include: base commit; branch name; HEAD commit; remote branch; every created, modified, deleted, renamed (old + new path), copied, generated and exported file; submodule changes if present; binary-file changes; and total diff statistics.

Required classifications:

```text
CREATED
MODIFIED
DELETED
RENAMED
COPIED
GENERATED
EXPORTED
UNCHANGED-BUT-VERIFIED
```

For every changed file, state: the exact path; classification; a concise purpose; the owning workstream or migration group; whether it affects runtime, database, configuration, documentation, tests, governance or export; and whether rollback removes or restores it. The generator emits exactly these columns per file — **Path · Classification · Git status · Domain · Workstream · Rollback · Purpose** — and no changed path may have an empty **Workstream** or **Purpose** value. Workstream is reproducible: it uses an explicit bracket prefix on the latest touching commit subject where present (e.g. `[W0]`, `[W1]`, `[MG-3]`, `[GOVERNANCE]`, `[EXPORT]`, `[CI]`) and otherwise falls back to a deterministic path-based classification.

The manifest is generated from commands equivalent to:

```bash
git diff --name-status --find-renames --find-copies <base>..HEAD
git diff --stat <base>..HEAD
git status --short --untracked-files=all
git log --oneline <base>..HEAD
```

The final report may add explanation, but it must not omit or contradict the generated Git manifest. **If the report's file list differs from Git, the delivery fails.**

### 4.1 Manifest self-reference protocol (`inventory_head` / `delivery_head`)

The complete-manifest rule requires that **every path changed between the Phase base and the final PR delivery HEAD is represented exactly once**. Because a committed manifest cannot contain the commit SHA that commits the manifest itself, use this deterministic, non-self-referential protocol:

- **`inventory_head`** — the committed HEAD immediately before the final delivery-only commit. It is the manifest's generation/provenance HEAD and is recorded in `governance/project-state.json` as `acceptance_candidate_head` (and `inventory_head`).
- **`delivery_head`** — the final PR HEAD (the delivery-only commit).
- The committed manifest must include the **complete `base..delivery_head`** path/status inventory. The manifest **records `inventory_head`** as its generation/provenance HEAD (its `HEAD commit:` line).
- The final delivery-only commit **may modify only paths already represented in the manifest** and must **introduce zero unlisted paths** (it (re)builds the manifest, export packs, checksums and the pointer/provenance only). Equivalently, every path that will exist in the final PR diff already exists in, or is enumerated by, the manifest generated for `delivery_head`.
- Governance CI **compares the manifest's complete path/status set against the actual** `git diff --name-status <base>..<delivery_head>`. **Any missing, extra, or status-mismatched path fails governance.** Export packs, checksums, manifests and provenance files are **not exempt** from the inventory.
- The Final Report and the PR body must record **both** HEADs (`inventory_head` and `delivery_head`) and the **actual final Git changed-file count**.

A substantive-only manifest (for example, one that lists the substantive source commit but omits the export packs/manifest/pointer paths that the final PR diff actually contains) **does not** satisfy this rule: it is not permissible for the committed manifest to represent fewer paths than `git diff --name-status base..delivery_head`.

## 5. Mandatory final report structure

Every Phase or milestone report must contain, in order: (1) simple Egyptian-Arabic explanation; (2) current Phase and authorized scope; (3) what was implemented; (4) practical effect; (5) risks and limitations; (6) acceptance tests with PASS/FAIL/DEFERRED/NOT-AUTHORIZED; (7) production and guest impact; (8) rollback status; (9) security and isolation results; (10) the complete generated changed-file manifest; (11) all commits created; (12) branch and PR information; (13) remote reachability of HEAD; (14) full working-tree status; (15) documentation and governance synchronization; (16) Project/Evidence Pack paths and checksums where applicable; (17) `PROJECT_STATE_GOVERNANCE` result; (18) `ZERO_STALE_LEFTOVERS` result; (19) remaining blockers; (20) exactly one next proposed action.

The canonical template is templates/PHASE_FINAL_REPORT_TEMPLATE.md.

**Forbidden summaries:** "docs updated"; "several files changed"; "related files modified"; "minor configuration changes"; any file list using ellipses; any report that excludes generated or deleted files.

## 6. Push and PR verification

Before reporting completion: commit all authorized changes intentionally; push the branch to GitHub; verify the pushed HEAD exists on the remote; open or update the single Phase PR; verify the PR base and head branches; verify all required CI checks; include the PR URL, the exact pushed HEAD SHA, and confirm the local and remote branch SHAs match. **A local commit is not a delivered result.** Do not claim GitHub delivery if the branch was not pushed.

## 7. Full-repository cleanliness

`git status --porcelain --untracked-files=all` must be clean before starting and before finishing (dirty only while the authorized task is actively being performed). **No permanent exception list for dirty files is allowed.** Generated build artifacts must be removed, restored, or explicitly untracked and ignored through a committed decision. Do not leave: local build outputs; temporary backups; secrets; logs containing PII; test databases; exported credentials; unexplained archives; or abandoned scripts.

## 8. Governance gates

**Before implementation:** `PROJECT_STATE_GOVERNANCE = PASS`; generated project-state blocks match the canonical state; transition history is valid; the current authorization permits the task; the full repository is clean.

**After implementation:** all acceptance tests pass or are truthfully classified; documentation is synchronized; the project-state transition is appended where authorized; the artifact registry is updated; the complete changed-file manifest is generated; repository and extracted-pack validation pass; `ZERO_STALE_LEFTOVERS = PASS`; the full repository is clean; the branch is pushed and the PR is available.

**Repository-side enforcement (GH-MANDATORY-CI).** GitHub Actions is the authoritative merge gate. The workflow `.github/workflows/project-governance.yml` (workflow name **Project Governance**, job **governance**) runs on every pull request targeting `master`, every push to `master`, and manual `workflow_dispatch`; it checks out full history (`fetch-depth: 0`), runs `python tools/project-state.py validate`, `python tools/project-state.py check-generated`, `python tools/tests/project_state_validator/run_mutations.py` and `bash tools/validate-project-state.sh`, and then asserts the working tree is still clean — failing on any non-zero step. It uses read-only repository permissions and performs no deployment, database access, migrations or production tests. **A PR is not merge-ready until this check is green** — local validator output alone is insufficient for a delivered PR. The default branch should be protected to require the `governance` check.

**How the required gates spend their time, and what is never recomputed twice (CI-REUSE).** The four
required checks run in parallel, so the delivery path is the slowest of them, twice: once on the
pull-request head and once on the merge commit. Two things were measured and changed.

*The adversarial mutation matrix is evaluated concurrently.* Each of its sixty cases costs a full double
validation — the structural validator plus the keyword validator over the whole tree, about sixteen seconds
on a runner — and they were evaluated one after another because they shared a single sandbox. Every worker
now gets its OWN sandbox and the cases run at once. Nothing about the checking changed: every case still
runs, both validators still run per case, `--require-full` still refuses a partial matrix, and the printed
`MUTATION_CASES_EXECUTED` count is still asserted against the total. `MUTATION_MAX_CASES` forces serial
execution, because that knob exists for the isolation regression's short overlapping child runs and giving
those an internal fan-out would change what that regression measures.

*Identical content is not validated twice.* Each gate first asks whether it has already proven THIS EXACT
TREE green, via `scripts/ci/evidence-reuse.sh`. The key is the GIT TREE HASH, and the answer comes from the
repository's own workflow-run history through the API, in that run. Two commits with the same tree have
byte-identical content in every tracked path — and `.github/workflows/**`, `tools/**`, `scripts/**` and
`governance/**` are all tracked, so an identical tree is also the same gate definition running the same
validators over the same inputs. A changed check is a changed tree, and a changed tree never matches. Only
successful runs of the SAME workflow count, so a green Phase-4 run can never satisfy governance. Every path
that cannot establish a match — no token, an API error, no candidate, an object the checkout lacks — reports
no hit and the full validation runs; reuse can remove duplicated work and can never be why something went
unchecked. Checks whose input is NOT the tree are never reused: the PR-metadata Zero-Stale check reads the
live pull-request body and runs unconditionally.

This matters because the merge commit's tree was byte-identical to the pull-request head's tree in thirteen
of the last thirteen merges — a merge introduces a commit, not content — so the post-merge run was
re-deriving a verdict it already held.

No Agent may bypass the governed execution wrapper or validators.

## 9. No stale leftovers

A completed Phase must not leave stale or contradictory plans, status text, code paths, feature flags, schema references, environment keys, role assumptions, runbooks, deployment files, tests, comments, exports, manifests or acceptance records (see the [Zero-Stale-Leftovers rule](ZERO_STALE_LEFTOVERS_RULE.md)). Retained legacy behavior must be registered in `governance/artifact-registry.json` with a lifecycle classification, exact reason, runtime status, replacement, removal gate and owning future Phase. Do not delete a required rollback path early — classify and gate it instead.

## 10. Phase delivery speed

The objective is fast, complete delivery without sacrificing production safety. For each approved Phase: use the approved Phase plan as the complete work breakdown; execute all included workstreams in one controlled run; fix test failures within the same branch; synchronize all directly-affected documents once at the end and whenever a milestone materially changes the authoritative state; generate one consolidated final report; produce one Phase PR. Do not send the Product Owner through repeated documentation-only loops when structural governance can detect and resolve the issue automatically.

## 11. Enforcement

This rule is enforced by:

- `tools/project-state.py validate` — asserts `authoritative_remote` points to `aibrahiiim1/StayConnectEnterprise`, that `delivery_governance` names this rule, the manifest generator and the report template (all present on disk), and that the `GH-*` decisions are registered.
- `tools/validate-project-state.sh` — keyword safety layer (bundled with the export packs).
- `tools/generate-change-manifest.py` — the deterministic changed-file manifest every final report must embed (columns: Path · Classification · Git status · Domain · Workstream · Rollback · Purpose).
- `.github/workflows/project-governance.yml` — the mandatory **Project Governance** CI check (GH-MANDATORY-CI), enforced structurally by `tools/project-state.py validate` and adversarially by `run_mutations.py` (missing workflow, removed command, missing PR trigger, ignored failures).
- `.gitattributes` — cross-platform **LF consistency** (`GH-LF-CONSISTENCY`): all checksum-controlled text is pinned to `eol=lf` and ZIP/binary artifacts are marked binary, so a Windows checkout, a Linux checkout and CI produce byte-identical, checksum-stable pack files. Without it, `core.autocrlf` materializes tracked text as CRLF on Windows and the keyword validator reports false pack-checksum failures. Enforced by `tools/project-state.py validate` and adversarially by `run_mutations.py` (weakened/removed policy).
- The decision register entries `GH-SOURCE-OF-TRUTH`, `GH-BRANCH-PR`, `GH-COMPLETE-MANIFEST`, `GH-FINAL-REPORT`, `GH-MANDATORY-CI` (`governance/decision-register.json`).

Run `make governance-validate` before any CONTROLLED implement/migrate/deploy/export, and `python tools/generate-change-manifest.py <base>..HEAD` before writing the final report **of a CONTROLLED delivery or milestone closure** — not after routine FAST-mode work, which produces neither a manifest nor a governance run (`CLAUDE.md` §0). A delivered PR must additionally show the GitHub **Project Governance** check green before it is called merge-ready.

## 12. Agent-owned Git and GitHub operations (`GIT_OPERATIONS_OWNER: AGENT`)

All Git and GitHub operations are performed by the authorized AI Agent through the authenticated tools. **The Product Owner must not be asked to execute Git, GitHub CLI or repository-management commands as the normal workflow.** Agent-owned operations include: fetch and pull; branch creation and switching; commits; pushes; remote verification; PR creation and updates; CI monitoring; merge execution; post-merge synchronization; branch cleanup; release/tag operations when separately authorized; and changed-file-manifest generation.

The Agent may request Product-Owner intervention **only** for unavoidable account-level or repository-UI settings that cannot be performed through the authenticated tools — for example an unsupported branch-protection setting, billing, organization policy, or an authentication approval. The Agent must not hand the Product Owner Git or `gh` commands to run as the routine path. This is decision `GH-AGENT-ONLY-OPERATIONS`, enforced structurally by `tools/project-state.py validate` (which requires the `GIT_OPERATIONS_OWNER: AGENT` assertion and the decision) and adversarially by the mutation suite.
