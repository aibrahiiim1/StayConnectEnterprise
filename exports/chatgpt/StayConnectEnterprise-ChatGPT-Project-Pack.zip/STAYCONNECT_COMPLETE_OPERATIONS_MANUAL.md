# StayConnect Enterprise — Complete Operations Manual

> **Audience:** an IT engineer who is new to StayConnect and has no knowledge of
> how the product was built. If you read this document top to bottom you can take a
> hotel from an unpacked appliance to live, licensed guest WiFi, and run it day-2.
>
> **This is the recommended starting point.** For screen-by-screen reference and
> shorter step lists, see the companion documents linked in
> docs/user-guide/README.md.
>
> Everything here is verified against the current production code (not against UI
> text or older docs). Where an operator-facing label differs from an internal
> value, both are given.

---

## Table of contents

1. [System architecture at a glance](#1-system-architecture-at-a-glance)
2. [Central vs Appliance — who does what](#2-central-vs-appliance--who-does-what)
3. [The one official onboarding workflow](#3-the-one-official-onboarding-workflow)
4. [Physical install & first boot](#4-physical-install--first-boot)
5. [WAN / LAN connectivity](#5-wan--lan-connectivity)
6. [Automatic registration → Pending activation](#6-automatic-registration--pending-activation)
7. [Activation: customer, site, license terms, one click](#7-activation-customer-site-license-terms-one-click)
8. [Convergence: how the appliance becomes Active](#8-convergence-how-the-appliance-becomes-active)
9. [The license model (states & enforcement)](#9-the-license-model-states--enforcement)
10. [Concurrent online guest capacity](#10-concurrent-online-guest-capacity)
11. [Guest networks / VLANs](#11-guest-networks--vlans)
12. [Worked examples: VLAN 100 & VLAN 200](#12-worked-examples-vlan-100--vlan-200)
13. [DHCP, DNS, NAT & the captive portal](#13-dhcp-dns-nat--the-captive-portal)
13a. [Guest portal settings](#13a-guest-portal-settings)
14. [Guest authentication methods](#14-guest-authentication-methods)
14a. [Guest sign-in protection (configurable)](#14a-guest-sign-in-protection-configurable)
15. [Access plans & vouchers](#15-access-plans--vouchers)
16. [Integrations: PMS, OTP, Social, Payments](#16-integrations-pms-otp-social-payments)
17. [Walled garden](#17-walled-garden)
18. [Guest zero-to-internet acceptance test](#18-guest-zero-to-internet-acceptance-test)
19. [License lifecycle behavior (Active → Grace → Expired → Suspended → Revoked)](#19-license-lifecycle-behavior)
20. [License renewal & anti-replay](#20-license-renewal--anti-replay)
21. [Reboot & service recovery](#21-reboot--service-recovery)
22. [Central outage behavior (offline operation)](#22-central-outage-behavior-offline-operation)
23. [Appliance replacement & WAN-MAC rebind](#23-appliance-replacement--wan-mac-rebind)
24. [Factory reset](#24-factory-reset)
25. [Deactivate / Revoke / Decommission / Delete](#25-deactivate--revoke--decommission--delete)
26. [Safe deletion & dependency order](#26-safe-deletion--dependency-order)
27. [Security alerts & certificate monitoring](#27-security-alerts--certificate-monitoring)
28. [Backup & recovery](#28-backup--recovery)
29. [Audit & monitoring](#29-audit--monitoring)
30. [Troubleshooting](#30-troubleshooting)
31. [Go-live checklist](#31-go-live-checklist)
32. [Day-2 operations checklist](#32-day-2-operations-checklist)
33. [Terminology (canonical operator terms)](#33-terminology-canonical-operator-terms)
34. [Advanced / exceptional: enrollment tokens & offline activation](#34-advanced--exceptional-enrollment-tokens--offline-activation)

---

## 1. System architecture at a glance

StayConnect has two tiers:

- **Central Control Plane** ("Cloud Admin", **Control Panel**) — a multi-tenant
  web app (`cloud-admin`, Next.js) backed by a Go API (`ctrlapi`/control-plane).
  You manage every hotel's customers, sites, appliances and **licenses** here.
  Central is the licensing authority and the fleet console.
- **Appliance** (the on-site gateway) — a hardened box running Go daemons and an
  on-box web app called **Hotel Admin** (`hotel-admin`, Next.js). The daemons:
  - `scd` — supervisor / guest-authorization / license state.
  - `edged` — resource CRUD (guest networks, DHCP, integrations) + Central channel.
  - `netd` — applies WAN/LAN/VLAN/nftables changes with an auto-rollback watchdog.
  - `portald` — serves the captive portal (`:8380` HTTP, `:8343` HTTPS).
  - `acctd` — traffic accounting & shaping.
  - Plus `caddy` (TLS reverse proxy for Hotel Admin), `kea` (DHCP), `unbound` (DNS).

The appliance **does not broadcast WiFi**. Your wireless controller / APs
broadcast SSIDs and tag them onto VLANs; the appliance is the gateway, DHCP
server, captive portal, firewall and license enforcer for those VLANs.

The trust between the two tiers is **mutual TLS (mTLS)** plus a **signed license**
and **signed assignment**. The appliance holds an Ed25519 identity key it
generates itself on first boot; Central never learns the private key.

---

## 2. Central vs Appliance — who does what

| Responsibility | Central (Control Panel) | Appliance (Hotel Admin) |
|---|---|---|
| Create customers, sites | ✅ | — |
| Activate an appliance, issue/renew/revoke its **license** | ✅ | — (shows state; can import an offline license file) |
| Fleet health, security alerts, certificates, audit | ✅ | Local health/audit only |
| Guest networks / VLANs, DHCP, DNS, NAT | — | ✅ |
| Captive portal branding, auth methods, walled garden | — | ✅ |
| Access plans, voucher batches, sessions | — (issues license terms) | ✅ |
| PMS / OTP / Social / Payments integrations | — | ✅ |
| WAN / LAN IP configuration | — | ✅ |
| Enforce concurrent-guest capacity & license state | — | ✅ (locally, offline-safe) |

**Rule of thumb:** Central decides *whether and how much* a hotel may serve (the
license). The appliance decides *how the hotel network actually works* and
enforces the license locally, even if Central is unreachable.

### Ownership hierarchy (how everything is organized)

```
Platform  →  Customer  →  Site  →  Appliance  →  Guest Networks / VLANs
```

- **Customer** = the hotel group / company / owner (a tenant). A Customer owns
  one or more Sites.
- **Site** = **one physical property** (a single hotel/resort/deployment
  location). A Site belongs to exactly one Customer and contains one or more
  Appliances. Buildings, floors, wings, SSIDs and guest VLANs are **not** Sites —
  they are configured on the appliance.
- **Appliance** = the on-site gateway. It belongs to exactly one Site at a time;
  moving it to another Customer's Site requires the explicit, audited
  cross-customer reassignment (never a silent move).

These rules are enforced in the UI, the API, **and** the database (a composite
foreign key makes an appliance-under-another-customer's-site impossible).

### Customer context (Control Panel)

The Control Panel has a **Customer context** selector at the top of the sidebar.
Platform admins pick **All Customers** or one specific Customer; the choice
persists across navigation and refresh. It scopes the customer-owned pages
(Sites, Appliances, Licenses, Operators, Audit, Dashboard) to the selected
Customer. **Creating a Site or Appliance requires a specific Customer to be
selected** — create forms show "Owner: <Customer>", and in All-Customers mode
creation is disabled until you choose one. A tenant operator has no selector and
is pinned to their own Customer (enforced server-side). See the Control Panel
reference for details.

---

## 3. The one official onboarding workflow

This is the **only** normal way to bring a hotel online. Use it every time.

1. **Install the appliance** at the site and cable WAN + LAN.
2. **Configure WAN** only if the site does not provide DHCP on the WAN uplink
   (many do — then this step is automatic).
3. The appliance **automatically appears in Central** under **Onboarding** as
   **Pending activation** (no token, no manual steps).
4. In Central, **create or select the Customer**.
5. **Create or select the Site**.
6. Set **Max Concurrent Online Guests** (the licensed capacity).
7. Set **License Validity** (valid-from / valid-until).
8. Set **Grace Period** (days the hotel keeps serving after expiry).
9. Click **Activate** — one click runs claim → assign → certificate → signed
   license.
10. **Wait for automatic convergence** — the appliance pulls its certificate and
    license itself; its status walks to **Active**.
11. **Verify Active** in Central (Onboarding/Appliances) and on the box
    (Hotel Admin → License).
12. On the appliance, **configure Guest Networks / VLANs**.
13. **Configure authentication methods** (voucher / OTP / PMS / social / payment).
14. **Perform a real guest acceptance test** (connect a device, reach the portal,
    authenticate, reach the internet).
15. **Go live.**

> Enrollment tokens are **not** part of this workflow. They exist only for the
> advanced/exceptional cases in §34. Do not hand installers a token for a normal
> install — a factory-clean box with internet self-registers on its own.

---

## 4. Physical install & first boot

- Rack/mount the appliance. Connect the **WAN** NIC to the site uplink and the
  **LAN/trunk** NIC to the switch that carries your guest VLANs.
- Reference topology used throughout this manual:
  - **WAN interface: `ens160`** (uplink to the internet / site network).
  - **LAN trunk interface: `ens192`** (802.1Q trunk to your switch; guest VLANs
    ride on it).
- Power on. On first boot with no stored identity, `scd` generates an Ed25519
  identity keypair, detects hardware (serial, WAN MAC, hardware fingerprint), and
  — if it has internet — self-registers with Central (see §6). No operator action
  on the box is required for a normal install.
- If the box has **no internet yet**, it simply waits; it will register as soon as
  WAN connectivity is established.

---

## 5. WAN / LAN connectivity

WAN/LAN is configured **on the appliance** in Hotel Admin → **WAN / LAN settings**
(`/network/system`). You normally only touch this if the WAN is static or the base
bridge gateway must change.

> This page covers only the **WAN uplink** and the appliance's **legacy base
> bridge** (`br-lan`). It is **not** where guest WiFi lives — each Guest Network
> has its own VLAN, bridge, gateway, DHCP pool and captive portal (see §11).
> Example: `CHR` → VLAN 90 → `ens192.90` → bridge `br-g90` → gateway `10.20.0.1/22`
> → DHCP pool `10.20.0.100–10.20.3.250`. The legacy base bridge is shown under an
> **Advanced · Base LAN / Legacy Bridge** section with a *Legacy* badge; its DHCP
> showing **off** there is normal when guests are served by Guest Networks.

1. Review the **WAN / Management** status card and the **Guest Networks** pointer.
2. Under **Change configuration**:
   - **WAN:** IP address, prefix length, default gateway, DNS (comma-separated).
   - **Base LAN:** base-bridge gateway IP, prefix length (guest DHCP pools are
     managed per guest network on the DHCP page, not here).
3. Click **Validate & preview** — check the before/after and the new management URL.
4. Click **Apply change** and **re-enter your password**.
5. A **countdown banner** appears. If the management IP changed, reconnect to the
   new URL, then click **Keep this configuration**.
6. **If you do not confirm within the window (default 120 seconds), the change
   auto-rolls-back.** A wrong IP can never lock you out.

The same apply-and-confirm safety wraps guest-network changes (§11).

---

## 6. Automatic registration → Pending activation

- A factory-clean appliance auto-registers by POSTing a **self-signed** request
  (proving possession of its identity key) to Central's public, token-less
  `POST /v1/appliances/register`. This is trust-on-first-use.
- Central creates the appliance record in state **`pending_approval`**
  (internal `lifecycle_state`), which the Control Panel shows to operators as
  **"Pending activation."** On the box's own setup screen the equivalent word is
  `pending_activation`.
- **Clone / hardware-reuse protection:** if a known identity key appears from
  different hardware, or a serial reappears with a new key while an active record
  exists, Central refuses (HTTP 403) and raises a **security alert**. The correct
  remedy is to **decommission** the old record first (§25).

You do **not** approve a raw registration by itself — you **activate** it (§7),
which both approves and licenses the box in one step.

---

## 7. Activation: customer, site, license terms, one click

In Central go to **Onboarding**, find the Pending appliance, and **Activate** it.
The form asks for exactly what the license needs:

- **Customer** (tenant) — create or select.
- **Site** — create or select (a site belongs to a customer).
- **Max Concurrent Online Guests** — the licensed capacity (use `-1` / "Unlimited"
  only where intended).
- **License Validity** — valid-from / valid-until.
- **Grace Period (days)** — how long the hotel keeps serving guests after the
  license expires.

Clicking **Activate** performs, server-side and atomically:

1. **Claim** the appliance.
2. **Assign** it to the customer/site and issue a **vendor-signed assignment**.
3. **Issue a certificate** — Central waits briefly for the appliance's CSR and
   issues its mTLS certificate (if the CSR hasn't arrived yet, it issues
   automatically the moment it does).
4. **Issue a hardware-bound signed license** with the terms you entered.

There is **no plan and no subscription** step. The signed appliance license *is*
the entitlement.

The appliance's internal `lifecycle_state` walks
`pending_approval → claimed → assigned → activated`, and then the licensing
reconciler maintains the time/license-driven states (`licensed`, `grace`,
`license_expired`).

---

## 8. Convergence: how the appliance becomes Active

Central does **not** push the license. The appliance **pulls** everything itself
over its authenticated channel:

1. It submits a CSR and fetches its issued **certificate**.
2. It then fetches its **signed license** from Central
   (`GET /v1/appliance/license`), immediately and on a periodic loop.
3. Once the valid license is installed, the box reports **Active** (Hotel Admin →
   License and Central → Appliances/Onboarding).

Convergence is normally seconds-to-a-minute. If Central is briefly unreachable
during this window, the box keeps retrying; fetch failures are non-fatal.

**Verify Active:** Central shows the appliance Active/licensed; Hotel Admin →
**License** shows **State: Active**, the **Max online guests**, and **Valid until**.

---

## 9. The license model (states & enforcement)

The license is a **signed document bound to one appliance** (identity key
fingerprint + appliance id + serial + hardware fingerprint + WAN MAC). It carries:

- **max concurrent online guests** (the capacity),
- **validity window** (valid-from / valid-until),
- **grace period** (days),
- **entitled features** (e.g. PMS, paid WiFi, SMS/email OTP, social login, HA,
  white-label) — features are real license fields, gated per-license.

The appliance evaluates state locally against the signed document and the local
clock. States and what they do to **new** guest logins:

| State | New guest logins | Existing sessions | DHCP/DNS/portal/Hotel-Admin |
|---|---|---|---|
| **Active** | Allowed, up to capacity | Keep running | Up |
| **GracePeriod** (expired but within grace) | **Still allowed**, with renewal warning | Keep running | Up |
| **Expired** (past valid-until + grace) | **Refused** (`license_expired`, 403) | Keep running to natural end | Up |
| **Suspended** (billing hold) | **Refused**; provisioning off | Keep running | Up |
| **Revoked** (explicit revocation) | **Refused** immediately | Keep running | Up |
| **Unlicensed / "Pending activation"** (no valid license) | **Refused** (fail-closed, capacity 0) | — | Up |
| **Restricted** *(legacy pre-v3 licenses only)* | Allowed, but provisioning/features off | Keep running | Up |

Key guarantees:

- **A state change never drops existing guest sessions** — only *new*
  authorization is refused.
- **DHCP, DNS, captive portal and Hotel Admin always keep running**, regardless of
  license state, so staff never lose control of the box.
- **Production appliances fail closed:** with no valid license the state is
  `unlicensed` and capacity is 0. (Only development builds run permissively.)

---

## 10. Concurrent online guest capacity

- The cap is **per-appliance, appliance-wide across ALL its guest VLANs** — it is
  **not** per-VLAN and **not** per-tenant. Two guests on VLAN 100 and three on
  VLAN 200 count as five against one capacity number.
- It is enforced **locally** on the appliance inside the same transaction that
  creates a guest session (a per-appliance lock + a live count of active
  sessions). Central is never consulted, so enforcement works offline.
- `-1` means **unlimited**.
- **At capacity**, a new guest login is refused with HTTP 403
  `{"error":"LICENSE_CAPACITY_REACHED","limit":N,"current":M}` and **nothing is
  provisioned** for that guest (no firewall/shaping/accounting/session rows). A
  slot frees when an existing session ends.

To raise capacity, **renew/re-issue the license** in Central with a higher
Max Concurrent Online Guests (§20).

---

## 11. Guest networks / VLANs

Create guest networks in Hotel Admin → **Guest networks** (`/network`) →
**New guest network**. The 7-step wizard:

1. **Identity** — Name, Description, **SSID label** (a label only — the appliance
   does not broadcast; your controller maps the SSID onto the VLAN).
2. **Interface / VLAN** — pick the parent interface (guest-access or guest-trunk).
   Tick **VLAN tagged (802.1Q)** and set the **VLAN id** (1–4094) for a tagged
   network.
3. **Subnet & gateway** — Subnet CIDR and Gateway IP. The appliance owns the
   gateway; guests use it as gateway **and** DNS.
4. **DHCP & DNS** — DHCP pool ranges; DNS mode (**appliance** resolver or
   **custom servers**); domain name; lease default/min/max.
5. **Captive portal** — toggle Captive portal, Internet access, **NAT
   (masquerade)**, **Client isolation**. Portal is served at
   `http://{gateway}:8380`.
6. **Review** — includes the "map SSID → VLAN on your controller" reminder.
7. **Apply** — **Create, validate & apply**, then **Confirm within the countdown**
   (default **120 s**) or it **auto-rolls-back**.

> **Immutable after creation:** network **type**, **VLAN id**, **parent
> interface**, and **bridge name**. To change any of these, delete and recreate
> the network. All other settings are editable on the network's detail page.
>
> A guest network **cannot be deleted while it is enabled or has active
> sessions** — disable it / let sessions drain first.

**DHCP reservations:** pin a device MAC to a fixed IP on **DHCP & leases**
(`/network/dhcp` → Reservations → New) or from the network's detail page.

---

## 12. Worked examples: VLAN 100 & VLAN 200

Reference hardware: **WAN = `ens160`**, **guest trunk = `ens192`**.

### Example A — two VLANs, two different portals/experiences

| | VLAN 100 (Guest) | VLAN 200 (Conference) |
|---|---|---|
| Subnet | `10.100.0.0/24` | `10.200.0.0/24` |
| Gateway (appliance) | `10.100.0.1` | `10.200.0.1` |
| DHCP pool | `10.100.0.50–10.100.0.250` | `10.200.0.50–10.200.0.250` |
| Portal | Portal A branding | Portal B branding |
| Auth | Voucher + room (PMS) | Voucher only |
| Portal URL | `http://10.100.0.1:8380` | `http://10.200.0.1:8380` |

Steps: create two guest networks on parent **`ens192`**, VLAN tagged, ids **100**
and **200**, with the subnets/gateways above; give each its own DHCP pool; enable
captive portal + NAT on both; apply + confirm each. On your wireless controller,
map SSID "Hotel Guest" → VLAN 100 and SSID "Conference" → VLAN 200. Set branding
per network in Portal settings.

### Example B — two VLANs sharing one portal/experience

Create VLAN 100 and VLAN 200 exactly as above but give them the **same** portal
settings and the **same** enabled auth methods. Guests on either VLAN see an
identical login page. This is common when you segment traffic (e.g. floors or
buildings) for routing/DHCP reasons but want one guest experience.

### Capacity across VLANs

In **both** examples the **licensed Max Concurrent Online Guests is a single
appliance-wide number**. If the license allows 300 concurrent guests, that 300 is
shared across VLAN 100 **and** VLAN 200 (and any legacy `br-lan`), not 300 each.

---

## 13. DHCP, DNS, NAT & the captive portal

- **DHCP** is served by `kea` per guest network from the pools you defined.
  Reservations pin a MAC to an IP.
- **DHCP option 114** advertises the captive-portal URL
  (`http://{gateway}:8380`) so modern OSes auto-pop the portal (RFC 8910). This is
  the only reliable cross-OS auto-pop mechanism.
- **DNS** is served by `unbound`, either as the appliance resolver or forwarding
  to custom servers per network.
- **NAT (masquerade)** is per-network — enable it so guests reach the internet via
  the WAN. **Client isolation** (per-network) stops guests talking to each other.
- The **captive portal** (`portald`) listens on `:8380` (HTTP) and `:8343`
  (HTTPS) and is reached at the network's gateway IP.

### 13a. Guest portal settings

**Hotel Admin → Guest portal → Portal settings.** How the sign-in page looks and
reads. There is one portal and one current configuration for it: change
something, watch the preview, press **Save changes**, and guests see it. There is
no draft to promote, no version to pick and no publish step.

| Section | What it holds |
|---|---|
| **General** | Hotel name, welcome line, help line, terms-of-use link. |
| **Branding** | Logo, background photograph, brand colour, button shade, text colour, corner radius, typeface. |
| **Languages** | Which languages guests are offered, and the wording in each. |
| **Advanced** | Custom CSS and a custom HTML fragment. |

**Images live on the appliance.** Upload a PNG, JPEG, WebP or GIF up to 8 MB; it
is stored locally and served from the same origin as the sign-in page, which is
what makes it load for a guest who has no internet yet. The file type is decided
by inspecting the bytes, not the filename. **SVG is refused** — it is a document
format that can carry script, and this page collects room numbers and voucher
codes.

**The preview is the real page.** It is the portal's own sign-in page rendered
with the settings you are editing, in a sandboxed frame at real Desktop and
Mobile widths — not a drawing of it that could drift.

#### Password confirmation: what needs it, and why

*Approved by the Product Owner, 2026-09-18.*

| Change | Confirmation |
|---|---|
| Hotel name, welcome/help text, terms link, logo, background, colours, typeface, corner radius, languages, wording | **None.** Save and it is live. |
| **Custom CSS or custom HTML**, including clearing them | **Password step-up required.** |

The reason is the boundary, not the screen. Those two fields are the only ones
that can put executable-shaped content on a page where guests type their surname
and voucher codes; every other field is constrained on the appliance to a colour,
a length, a font stack, a bounded string, or an appliance path / https URL /
inline image, so a save that leaves the Advanced fields untouched cannot
introduce executable content at all. Requiring a password to correct a typo in
the hotel's name was ceremony that taught operators to type it without reading.

What is unchanged: the operator still needs the portal-branding write
permission, every save is audited with who made it, and a design containing a
script tag, an inline event handler, a frame, an extra form or `@import` is
**refused outright** rather than quietly cleaned up.

#### Languages, and how a guest gets theirs

Six languages ship complete with the product — **English, Arabic, Italian,
French, Russian, German** — so offering one costs a tick, not an afternoon of
translation. Two separate things, deliberately:

- **Guest languages** — which of them appear in the portal's selector. English is
  always available and is what anything missing falls back to.
- **Wording** — one language at a time, every field already showing the real text
  a guest reads. Type over a string to change it for your property; press its
  reset button, or type the original back, and the customisation is removed
  rather than stored. **Only strings you actually changed are kept**, so improved
  wording reaches your guests without you re-entering anything.

A language you add yourself is not shipped with the product, so you supply its
wording; anything left empty shows English, and the screen says how many strings
that is.

**Arabic is laid out right to left** on the portal and in the editor.

**A guest's language is chosen automatically**, in this order:

1. what that guest chose on this device before, if they chose;
2. otherwise their device's own ordered language list, first entry the hotel
   offers — `ar-EG` matches Arabic, `de-AT` matches German, and a phone set to
   Japanese then Italian gets Italian at a hotel offering Italian;
3. otherwise English.

A guest's own choice always outranks detection and survives being bounced back
to the portal. Detection never records a preference, so it cannot be mistaken
for a choice later. If you switch a language off after a guest chose it,
detection simply runs again for them.

---

## 14. Guest authentication methods

Guests can authenticate by:

- **Voucher** — a printed/emailed code (needs Access plans + Voucher batches, §15).
- **Username & Password (Guest Accounts)** — a named account with a password,
  bound to an Access plan (§15). Basic-access like vouchers (no license feature
  gate). Managed on **Hotel Admin → Guest accounts**; the portal tab is shown only
  when you enable it there. Passwords are stored hashed (argon2id) and are
  write-only.
- **OTP** — email or SMS one-time code (needs a Notifications provider, §16).
- **PMS** — room number + name checked against the hotel PMS (needs a PMS
  provider, §16).
- **Social login** — Google/Apple/Facebook/Microsoft (needs a Social provider).
- **Payment** — paid WiFi via Stripe (needs a Payments provider).

All methods share the **same** authorization pipeline (credential check → license
state → atomic appliance-wide capacity reservation → session → nft → shaping →
accounting); a failed login creates no session or authorization. Which methods you
may use depends on what you enable **and** what the license entitles (the License
page's Entitlements table shows the licensed features; voucher and
username/password are always available).
Make sure the portal, payment and OAuth callback hosts are reachable **before**
login via the **Walled garden** (§17).

---

## 14a. Guest sign-in protection (configurable)

Repeated incorrect room sign-ins from the **same device** cause that device to be asked to wait before it can
try again. It is always on — there is no switch — and the three numbers that decide how strict it is are
editable in **Hotel Admin → Sign-in methods → Guest sign-in protection**.

| Setting | Unit | Default | Allowed | What it does |
|---|---|---|---|---|
| Maximum failed attempts | attempts | **5** | 3–20 | How many incorrect sign-ins from one device are allowed before it has to wait. |
| Observation window | seconds | **60** | 30–3600 | Attempts older than this stop counting. The window moves continuously (rolling), so it cannot be sidestepped by waiting for a clock boundary. |
| Wait after too many attempts | seconds | **60** | 30–3600 | How long the device is asked to wait. Attempts made during the wait do not extend it. |

**Scope is the device, on its site and guest network.** Not the room — restricting a room number would lock
out the guest who actually lives there while whoever chose that number simply moves to the next one. Not the
address — a guest network NATs, so an address is a floor. The hardware address used is the one the appliance
reads from its own neighbour table, never a value the browser sends, so refreshing the page, reopening the
portal, clearing cookies or typing a different room does not reset anything.

*Honest limit:* a MAC address is not unspoofable. Someone on the guest VLAN who changes their device address
gets a fresh counter. What the control buys is that casual enumeration stops being free, that no guest is ever
restricted by another guest's behaviour, and that every restriction is attributable and releasable by a named
member of staff.

**What counts, and what does not.** Only an incorrect credential counts:

* `CREDENTIAL_MISMATCH` — the room exists and has an eligible stay, but the value entered matched nothing.
* `ROOM_NOT_IN_MIRROR` — no stay on any mapped interface carries that room number.

Nothing else does. A stale or unreachable PMS mirror, a routing or interface failure, an internal error, a
malformed submission, an ambiguous room, a stay outside its eligibility window and an attempt already refused
for waiting all leave the counter untouched — a property whose PMS feed is down must not lock out its own
guests on top of it. A **successful** sign-in clears that device's counter immediately.

**What the guest sees.** *"Too many attempts. Please wait N seconds and try again."* — counting down from the
server's own expiry. A browser that ignores the countdown gains nothing: the appliance refuses the next
submission itself.

**Existing sessions are never disconnected.** A guest already online stays online.

**Ending a wait early.** **Hotel Admin → Guest sign-in attempts → Active restrictions** lists every device
currently waiting, with its guest network, the last room it typed (shown as *unverified input* — it is what
somebody typed, not where anyone is staying), the failure count, when the wait started and ends, a link to
that device's sign-in attempts, and a **Release** action.

Release needs the *Release guest sign-in restriction* permission and a short reason; who released it, which
device, when and why are recorded. **Releasing allows another attempt — it does not sign anybody in.** The
guest still has to enter details the property accepts.

**Who can do what** (see ROLE_AND_SCOPE_MATRIX.md §3):

| Role | Change the settings | Release a restriction |
|---|---|---|
| Site admin | yes | yes |
| Hotel IT manager | yes | yes |
| Front office operator | no (read-only) | yes |
| Guest relations operator | no (read-only) | yes |
| Site viewer | no | no |

The desk releases and does not re-tune, deliberately: turning "five" into "twenty" for the whole property
must not be the quickest way to help one person.

**Changes take effect immediately**, on the next sign-in attempt — no restart, rebuild or deployment. They
apply to what happens **next**: a device already waiting keeps the time it was given, and shortening the
setting does not end a wait already running. Use **Release** for that. Every settings change records the
operator, the previous values and the new values.

---

### PMS configuration: Current configuration and History

**Hotel Admin → Property management system → PMS connection.**

The connection screen shows the **current configuration** only — the version in force, what it is set to, and
when and by whom it was saved. Previous versions are behind a **History** button, and putting an older one
back in use ("roll back") is done from there.

Every saved version is kept permanently and cannot be edited or removed. History states what changed from the
version before it, derived from the stored values. Where two versions hold identical connection settings,
History says so and names the internal difference instead of implying a change that did not happen. Where a
version's origin was never recorded, History says that too rather than guessing.

The word *Revision* is internal. Operators see **Version**, **Current configuration**, **Previous** and
**History**; the database and the API are unchanged.

**Connection recovery settings apply to this connection only.** They are stored per PMS interface, so a
property running two connections tunes each on its own terms -- a link behind a flaky VPN can be given
patient backoff without slowing down a healthy one. Changing one connection's values leaves every other
connection at the property exactly as it was, and each keeps its own change history.

Where a version's origin cannot be read at all -- as opposed to never having been recorded -- History says
so explicitly and names it as a fault to report. The configuration itself is still shown: losing the audit
trail never costs an operator the ability to see what the connection is set to.

## 14b. Unresolved departures (PMS reconciliation)

**Hotel Admin → Property management system → PMS connection → Advanced diagnostics → Unresolved departures.**

> **Not a routine screen, and deliberately not in the menu.** Reconciliation runs by itself after every
> complete guest list and this page carries no action. A property where the integration is healthy never
> needs to open it. When something genuinely needs investigating, the PMS connection page says so — under
> *Needs investigation* — and links straight here. Roster reconciliation sits beside it, under the same
> Advanced diagnostics heading.

This PMS reports every checkout as a departure carrying a **room number and no reservation number**. When the
room does not identify exactly one in-house stay, the departure cannot be applied and waits for a human. Two
things then used to happen that made the backlog unusable: a waiting departure is **restaged on every
reconnect**, and the dashboard counted rows. One unresolved checkout became thousands of "messages needing
attention".

The screen now counts **decisions**, not rows. One departure is one case, with the number of recorded copies
shown beside it — that number is a fact about the feed and is not hidden.

**What a case can say, and what it needs:**

| State | Meaning | What would resolve it |
|---|---|---|
| **The PMS can settle this now** | One matching stay, it began before the departure was raised, and it is absent from the PMS's own latest complete in-house list. | A departure sent from the PMS for that room will apply cleanly. |
| **Nothing outstanding** | Nobody is in that room now. | Nothing is waiting. This is **not** proof the departure was applied. |
| **Room has more than one stay** | Sharing a room is ordinary and legal. | The reservation number from the PMS. |
| **A later guest is in that room** | The current occupant arrived **after** this departure. Applying it would check out a resident guest. | The reservation number from the PMS. |
| **The PMS still lists them as in house** | Fresh authoritative evidence contradicts the older departure. | The PMS resolving its own disagreement. |
| **Needs evidence from the PMS** | Usually: no complete in-house list has been received to compare against. | A completed full synchronisation. |

**There is no action on this screen, and that is the answer rather than a gap.** A departure the appliance
could not place is resolved by the PMS sending one it *can* place — typically once somebody corrects the
record there. Two deliberate invariants make that the only route: a PMS event is one-way (once it reaches a
terminal state its result is frozen), and a checkout boundary must be an *applied* departure event. The PMS
is the source of truth for whether a guest has left, and the appliance asserting it from a re-reading of an
old message would be claiming to know something it does not.

The list is the value: 397 distinct departures instead of 12,271 rows, each labelled with the evidence it is
waiting for, so the desk knows which rooms to ask the PMS about.

**Three rules this screen will not break**, because breaking any of them disconnects a resident guest:

* a **planned departure date is not a checkout** — "Past their departure date" is its own tab and closes nothing;
* **two stays in one room are not a duplicate** — shared occupancy is ordinary;
* an **old room-only departure is never applied to today's occupant**.

The engine enforces the third one itself: a departure whose matching stay arrived later is refused as
`GO_STALE_ROOM_DEPARTURE` rather than applied.

---

## 14c. Reporting to the StayConnect cloud

**This appliance uses the StayConnect cloud for its licence only.**

Operational reporting is switched off by a Product-Owner decision of 2026-09-13. It is not broken and does
not need reconnecting. Hotel Admin shows the state as **Licensing only** on **Network → Cloud connection**.

**What the appliance still sends,** and nothing else — all of it HTTPS, none of it over the messaging
transport:

* its **licence**: activation, retrieval, renewal, validation, and offline reconciliation;
* its **identity**: registration and enrolment;
* the **certificate** that authenticates those calls, and its renewal;
* a periodic **licence-enforcement check** — this is how an appliance that has been deleted at the cloud
  discovers it is orphaned and stops serving on a licence it has cached;
* the **signed assignment** that says which customer and site this appliance belongs to, which is what the
  licence is scoped to. It is re-verified on this appliance every time it starts.

**What it no longer sends or accepts:** usage and health summaries, service-health reports, licence
acknowledgements, remote disconnection of a guest, remote PMS tests, remote PMS configuration, remote
commands, and software-update instructions. Every one of those was reporting or remote control; none was
licensing.

### The retained allowlist, in full

Every exchange the appliance is still permitted, what it carries, and how often. Nothing else is sent, and
nothing at all goes over the messaging transport.

| Exchange | Purpose | What it carries | Cadence |
|---|---|---|---|
| `POST /v1/appliances/register`, `/enroll` | establish this appliance's identity | appliance id, hardware serial, public key | once, and on orphan recovery |
| `POST /v1/appliance/csr` → `GET /certificate` | obtain and renew the client certificate | certificate signing request; the issued certificate | on issue and before expiry |
| `GET /v1/appliance/license` | activation, retrieval, renewal, validation | appliance id; the signed licence document | ~hourly, plus on demand |
| `POST /v1/appliance/offline-reconcile` | reconcile a licence used offline | licence reference and offline usage counters | on reconnect after offline use |
| `GET /v1/appliance/hello` | **licence enforcement** — detects that this appliance was deleted at the cloud, so it stops serving on a cached licence | signed appliance id only | every 10 minutes |
| `GET /v1/appliance/assignment`, `/assignment-registry`, `POST /assignment/ack` | **licence enforcement** — carries revocation, decommission and re-assignment; the appliance stops serving the guest plane when the assignment no longer grants | signed document: customer, site, state, version. Acknowledgement returns the version adopted | every 30 seconds |

**No guest identity, stay, session, usage or log content appears in any of them.** The licence and assignment
calls carry the appliance's own identity and signed documents about that appliance; nothing describes a
guest, a room or a reservation.

**All of it is mutually-authenticated HTTPS to the control API.** The assignment channel is certificate-only
by design — there is no token fallback, so a document can only reach an appliance holding a valid client
certificate.

**Nothing local changed.** The PMS connection, mirrored stays, guest sign-in and its attempt records,
packages, allowances, sessions, accounting, enforcement and every Hotel Admin screen run on this appliance
and are unaffected. A guest does not need the cloud to get online, and the offline licence and grace rules
are unchanged.

**The records produced while reporting was enabled are kept, not deleted.** They stay on the appliance and
are removed only by the ordinary retention period below, measured from the day each was delivered.

---

### The queue, retention and recovery (while reporting is enabled)

The remainder of this section applies to an appliance running in full reporting mode. On a licensing-only
appliance the queue is static: nothing is added to it and nothing is sent from it.



**Hotel Admin → Network → Cloud connection.**

The appliance keeps working when the cloud is unreachable. Everything it reports upward — usage totals,
health, alerts — is written to a local queue first and sent later. **No guest is affected by this queue**:
sign-in, speed and the PMS all run locally.

**The card accounts for every record**: delivered, waiting, given up on, and the total. If the three do not add
up, the card says so rather than showing the smaller number.

**Why a queue is not draining is reported as a fact, not guessed from its size.** The four states are different
problems with different owners:

* **No connection to the cloud** — the appliance cannot reach it. Records are safe and go out when it returns.
* **The cloud is not listening** — the appliance reaches the cloud and nothing there is consuming this
  appliance's reports. **Cloud-side; the hotel network is not the cause.**
* **The cloud refused the records** — it answered and declined. Retrying will not help; how this appliance is
  registered needs looking at.
* **Sending** — the queue is draining, oldest first. A large queue that is moving is progress, not a fault.

**Keep delivered records for (days)** — default **30**, allowed 1–365. It removes records that have **already
been delivered**. Records still waiting, and records the appliance gave up on, are **never** removed by it: a
queue that cannot be delivered is not made to look empty by deleting it.

**Recover these records** appears when the appliance has given up on some. Retries are finite, and a record
that exhausts them is set aside and will not be sent again on its own. Recovery returns a bounded batch to the
queue, oldest first; nothing is deleted or altered, and the cloud records each record once however many times
it arrives. It needs a typed reason, is recorded with the operator's name, and may need running more than once
— the card shows how many are left.

---

## 15. Access plans & vouchers

**Access plan** (Hotel Admin → **Guest access plans** → **New plan**): Code, Name,
Description, **Duration (s)** (blank = unlimited time), **Data cap (bytes)** (blank
= unlimited), **Down/Up kbps**, **Max devices**, **Price (cents)**, **Currency**.

> "Max devices" on an access plan is a **per-credential device limit** — the
> concurrent devices allowed on one voucher or one guest account — a different
> concept from the license's appliance-wide concurrent-guest capacity (§10). Both
> are enforced on **every** login, atomically and concurrency-safe: a device
> rejected for either reason gets `MAX_DEVICES_REACHED` / `LICENSE_CAPACITY_REACHED`
> and no session/nft/shaping/accounting/voucher-activation is created. A reconnect
> from a device already signed in on the same credential does **not** consume a
> second slot; disconnect/expiry/reap frees the slot. Guest Access Plans are the
> per-guest tiers here — not the retired commercial *License Plans*.

**Voucher batch** (**Voucher batches** → **New batch**): choose an active **Plan**,
a **Count** (1–10000), a **Label**, and the **code generation options**:
- **Code length** 6–10 — the **random portion** only.
- **Character mode**: **Numbers** · **Uppercase letters** · **Uppercase letters
  and numbers** · **Uppercase/lowercase letters and numbers**. The form shows a
  live **example** and the exact **character set**.
- **Optional prefix** (A–Z/0–9, e.g. `PARTY`) — **additional** to the random
  portion.
- **Exclude ambiguous characters** (on by default): drops `0/O`, `1/I/L`, `5/S`.
  (`I, L, O, U` are *always* excluded so a code matches exactly what the guest
  types.) Codes use secure random generation and are globally unique; a batch too
  large for the chosen space is rejected rather than weakening randomness.

> **Voucher duration model (canonical):** a voucher's plan **Duration** is a
> **validity window** that opens at the voucher's **first activation** and runs
> on **wall-clock** time. The window end (`Valid until`) is fixed at that first
> use and is **durable** — it never moves for reconnects, extra devices, a crash,
> a service restart or a reboot. So a "10-minute" voucher gives **10 minutes of
> total access from first use**, shared by all devices the plan's Max devices
> allows; a second simultaneous device does **not** make the clock run faster,
> and disconnecting/reconnecting neither pauses nor resets it. Once the window
> closes the voucher shows **Expired** (reason: time). The **Data cap** is an
> **aggregate** across every session/device; when the combined usage reaches the
> cap the voucher shows **Exhausted** (reason: data). Consumed time and data are
> **derived** from the durable window and a live sum of session bytes — never
> accrued on session close — so usage is counted exactly once and a duplicate or
> retried close can't double-charge. (Guest **accounts** are reusable credentials
> by design — each login gets the plan duration afresh.)

Then **view the codes** (search/filter, copy, print, **download CSV**), open a
code for its **Details** (state, plan, duration, speed, data cap, max devices,
active devices, dates), **revoke** an unused code, or **Revoke unused** for the
batch. **Change a voucher's plan** from a dropdown — for one voucher or the batch
(*Unused only* / *All eligible*): unused vouchers change at once, a voucher with a
**live session** is never repointed (end it first), and revoked/expired/exhausted
vouchers can't be changed. The code, usage history and audit trail are preserved;
each change records previous plan, new plan, operator and reason. Legacy (12-char)
batches keep working unchanged.

**Guest accounts** (**Guest accounts** → **New account**): **username** (1–64;
one letter/digit allowed; case-**insensitive**, unique per property), **password**
(1–128, case-**sensitive**; short is allowed with a non-blocking weak-password
warning), an active **Plan** (dropdown showing duration/speed/max-devices), and
optional display name / valid-from / valid-until / notes. The password can be typed
(show/hide) or **Generated**, and is shown **once** afterwards with **Copy** — it
can never be retrieved later (only an Argon2id hash is stored; no read/list/export/
log/audit ever returns it). **Edit** any account in place (username, password,
plan, display name, validity, enabled, notes — no delete/recreate); plan changes
apply to **future** logins while a running session keeps its policy. The list shows
**active devices** (e.g. `1 of 2`), locked status, validity and login history; per
account you can **Disconnect** active devices and (on reset) optionally disconnect
existing sessions. Toggle **Show Username & Password tab on the captive portal** to
expose the method. Wrong/unknown/disabled/expired/locked all return one **generic**
error and create no session; per-account lockout plus layered throttling
(username+IP, username+device, endpoint-wide) damps brute force.

New plans/voucher batches/guest accounts require the license to permit
provisioning — if the license is Expired/Suspended/Revoked/Unlicensed you'll get a
"license doesn't currently allow…" error; renew or activate first.

---

## 16. Integrations: PMS, OTP, Social, Payments

- **PMS providers** → **New provider**: Name, **Kind** (`protel-fias` /
  `opera-fias` / `fidelio-fias` for FIAS; `mews` / `apaleo` for REST; `stub` for
  testing), Display name. FIAS: Host, Port, Auth key (write-only), Use TLS. REST:
  Base URL, API key (write-only), Property ID. Use **Test**, **Health**, **Cache**.
- **Notifications** (OTP email/SMS) → **New**: Channel (email/sms), Kind
  (`sendgrid`/`ses` for email; `twilio` for sms; `stub`), Display name, API key
  (write-only), API user (Twilio SID). Email adds From address / From name.
- **Social login** → **New**: Provider (google/apple/facebook/microsoft), Display
  name, Client ID, Client secret (write-only), Redirect URI, Scopes.
- **Payments** (Stripe) → **New**: Display name, Publishable key, Secret key
  (write-only), Webhook secret (write-only), Success/Cancel URLs. Recent purchases
  show in **Recent payments**.

---

## 17. Walled garden

Hotel Admin → **Walled garden** → **New rule**: Kind (domain/ip/cidr), Value,
Ports (comma; blank = all), Description. Add the hosts your portal, payment
callbacks and OAuth redirects need so guests can reach them **before**
authenticating. Keep the list small.

---

## 18. Guest zero-to-internet acceptance test

Do this before go-live, on a real device, per guest VLAN:

1. Join the guest SSID (mapped to the VLAN on your controller).
2. Confirm the device gets a DHCP lease in the expected subnet and the gateway/DNS
   is the appliance gateway IP.
3. Confirm the **captive portal auto-pops** (or browse to any HTTP site and get
   redirected to `http://{gateway}:8380`).
4. Authenticate with a real method (voucher/OTP/PMS/social/payment).
5. Confirm the device **reaches the internet** afterwards.
6. Confirm the session appears in Hotel Admin → **Sessions**.
7. Confirm the **concurrent count** increments (License page / dashboard).

If capacity is reached during testing you'll see `LICENSE_CAPACITY_REACHED` —
that's expected behavior, not a fault.

---

## 19. License lifecycle behavior

See the table in §9 for the enforcement matrix. Timeline of a normal license:

- **Active** from valid-from until valid-until.
- At **valid-until** it enters **GracePeriod** for `grace_period_days` — guests
  keep working, staff see renewal warnings.
- After **valid-until + grace**, it becomes **Expired** — new logins refused,
  existing sessions drain, the box stays up.
- **Suspended** and **Revoked** are administrative (billing hold / explicit
  revocation) and take effect on receipt regardless of dates; Revoked is the
  strongest and is delivered as a signed notice so the box stops even if it later
  reconnects.
- **Unlicensed** is the fail-closed default when no valid license is installed.

---

## 20. License renewal & anti-replay

- **Renew / change terms** in Central (Licenses → renew/re-issue, or re-activate).
  Every re-issue gets a **new, higher license version** and supersedes the prior
  one atomically. The appliance pulls the new envelope automatically.
- **Anti-replay is enforced on the appliance and survives reboot** (cleared only
  by factory reset):
  - **Monotonic version** — a lower version, or the same version under a different
    license id/fingerprint, is rejected even with a valid signature and Central
    offline.
  - **issued-at may not go backwards.**
  - **Revoked ids can never be re-installed.**
  - **Clock-rollback protection** via a persisted high-water mark (48h tolerance).
  - Rejections surface as `LICENSE_ROLLBACK_REJECTED`.

This means you cannot "downgrade" a hotel by replaying an old license file, and a
renewal issued while the box is offline still applies cleanly when it reconnects.

---

## 21. Reboot & service recovery

- The appliance daemons are supervised. On crash/reboot they self-heal with an
  adaptive backoff; Hotel Admin → **Diagnostics** (`/health`) shows each service's
  health, restart counts, backoff and recovery history.
- License state and anti-replay high-water marks are persisted, so a reboot does
  not change licensing.
- You should not normally intervene. If needed: **Recheck** re-runs a health
  check, **Logs** shows recent sanitized logs, and **Restart** (reason + password)
  restarts a service.

---

## 22. Central outage behavior (offline operation)

- **Guests keep working.** Guest authorization and the capacity gate evaluate
  entirely against the on-disk signed license and the local clock — nothing in the
  guest path calls Central.
- License fetch/refresh failures are **non-fatal** ("offline-safe"); they only
  affect renewal freshness and set a **Cloud validation stale** warning flag (a
  warning, not a state change).
- DHCP, DNS, portal and Hotel Admin are local and unaffected.
- Time-based transitions (Active → Grace → Expired) still occur offline via the
  local ticker, honoring the grace window.
- For fully offline sites, an **offline activation file** can be imported on the
  box (§34).

---

## 23. Appliance replacement & WAN-MAC rebind

**Replace** (swap hardware, keep the site): Central → appliance → **Replace**
mints a **72-hour single-use replacement token** bound to the same customer/site.
The **old box keeps its license until the replacement goes Active**, then the old
one is auto-terminated (bounded overlap). Use this for RMA / hardware swaps.

**WAN-MAC rebind** (same box, WAN NIC changed): a WAN-MAC-only mismatch is
**soft** — the license stays installed, the hotel keeps running in a mismatch
grace state, and a security alert is raised. Resolve it in Central →
appliance → **Rebind MAC** (new MAC + reason + confirm + step-up), which re-issues
a corrected hardware-bound license and clears the alert.

> A mismatch of **identity key / appliance id / serial / hardware fingerprint** is
> a **hard** reject — the license is refused and the box will not serve guests.
> That indicates the license and hardware genuinely don't match (wrong file, or a
> cloned box), not a simple NIC change.

---

## 24. Factory reset

- Factory reset is a **local appliance action**, not a Central action. It wipes the
  box's identity, license and config.
- Central authority is **not** deleted by a factory reset; the box is reconciled on
  its next hello. If you are permanently retiring the box, use **Decommission** or
  **Delete** in Central (§25) so its bound license is revoked.
- After a factory reset the box is factory-clean again and will self-register as
  Pending activation if it has internet.

---

## 25. Deactivate / Revoke / Decommission / Delete

All are Central actions with a single, shared rule: **every terminal path revokes
the appliance's bound license.** Choose by intent:

| Action | Reversible? | What it does |
|---|---|---|
| **Deactivate** | ✅ Yes | Revokes the bound license, drops the appliance to `assigned`, **keeps** identity/cert/assignment so it can be re-activated later. |
| **Revoke** | ❌ Terminal | Marks `revoked`/`retired`, revokes the bound license, and delivers a **signed revoked assignment** so the box stops even if it reconnects. |
| **Decommission** | ❌ Terminal | Same terminal path as Revoke (bound license revoked + signed terminal assignment). Use when permanently retiring hardware. |
| **Delete** | ❌ Permanent | Requires typing the **serial** + reason + password step-up. Revokes bound licenses and certs, then deletes the record (cascading assignments, certs, commands, networks, lifecycle events — terminating mTLS/NATS trust). |
| **Reassign** (cross-tenant) | — | Revokes the previous tenant's bound license and reassigns the box to a new customer/site. |

> **Site-wide licenses** (licenses not bound to a specific appliance) are
> deliberately **left valid** by these appliance-level actions.

### Cross-customer transition & secure data purge

An appliance's local site database holds tenant-owned guest data (access plans,
vouchers, sessions, guest PII, PMS/notification/social/payment **credentials**,
walled garden, portal config, operators, usage/accounting). When an appliance
moves to a **different Customer** — a genuine reassignment, or a Customer that was
**deleted and recreated** (a new tenant UUID), decommission-and-reuse, or an
ownership transfer — that previous customer's data must never remain readable
under the new owner.

The appliance enforces this automatically, comparing **immutable tenant UUIDs**
(never names/slugs):

- **Same-customer** deactivate/reactivate (same tenant UUID) → **all tenant data
  is preserved** (plans, vouchers, sessions stay valid).
- **Cross-customer** transition (different tenant UUID) → on the next boot the
  appliance **securely purges every previous-tenant row and cached secret** in one
  transaction *before it authorizes any guest*: it repoints the live guest
  networks (VLAN/DHCP/portal stay up) to the new owner, deletes all foreign-tenant
  rows across every tenant-owned table + the local tenant/site mirror, drops
  pending outbox events queued under the old identity, flushes runtime guest
  authorization (nftables), and writes an **audited transition record**
  (`appliance.tenant_transition_purge`) with the purged counts.
- **Fail-closed:** if the purge cannot complete, the appliance authorizes **no**
  guests (`tenant_transition_pending`) until it succeeds — a partial cleanup can
  never expose one customer's data to another. The purge is idempotent, so a
  retry (or reboot) completes safely.

Preserved across a transition: appliance/system/network/bootstrap state (WAN/mgmt,
identity, certs, guest-network topology) and the immutable security **audit
history**. Guest-facing data and secrets are not.

---

## 26. Safe deletion & dependency order

StayConnect never silently cascades a customer/site delete. Deletion is **blocked
while owned records still exist**, and the dialog lists exactly what to remove.

**Teardown order:** **Appliances → Site → Customer.**

- Delete/decommission the **Appliances** first (this revokes their bound licenses).
- Then delete the **Site** (a site with appliances is blocked).
- Then delete the **Customer** (a customer with sites is blocked).

There is **no subscription step** in the teardown — subscriptions were retired and
are never a delete blocker.

Notes verified in code:
- An **appliance delete** itself is unconditional once you type its serial (it
  relies on database cascade for its own dependents); the safety is the typed
  serial + password step-up + license/cert revocation, not a session check.
- A **guest network** cannot be deleted while enabled or with active sessions.
- A **customer hard-delete** purges its archived legacy data as part of the
  operation (legacy read-only guards are handled server-side in-transaction).

---

## 27. Security alerts & certificate monitoring

- **Security alerts** (Central) surface clone/hardware-reuse attempts, WAN-MAC
  mismatches, permissive-license attempts and similar events. Triage them on the
  **Security alerts** page. A hardware-reuse alert usually means an old record must
  be decommissioned before the new box can register.
- **Certificates** (Central) tracks appliance mTLS certs and expiry. On the box,
  the Hotel Admin **TLS certificate** page auto-renews the on-box cert (45-day
  window / on IP change / SAN drift); **Rotate** forces a fresh cert (reason +
  password; you never upload a key).

---

## 28. Backup & recovery

- Both Central and the appliance run automated backup with fail-safe
  artifact retention. Cleanup never deletes the current/previous release, the
  newest DB backup, PKI material, or pinned artifacts.
- Central exposes a **Backup health** page (and a backup-health API) so you can
  confirm backups are current across the fleet.
- For disaster recovery of an appliance, prefer **Replace** (§23) — it preserves
  the site binding and licenses cleanly.
- **Three `public` tables are created by `scd` at first use, not by any
  migration** — `edge_executed_commands`, `edge_installed_updates` and
  `edge_offline_packages`. They are in any dump taken from a running appliance,
  but a database rebuilt from migrations alone will not have them, and Gate P's
  grants fail without them. See
  BACKUP_AND_RESTORE.md §"Three public tables no
  migration creates".

### Verifying an appliance after a reboot or a restore

Two scripts re-run the acceptance checks on a live appliance. Both are
read-only or self-restoring, contact no Production system, and enable nothing:

```sh
bash deploy/scripts/phase7-appliance-m4.sh      # the assembled system: services,
                                                # roles, boundaries, darkness,
                                                # backup+restore, restoration proof
bash deploy/scripts/phase7-final-reboot.sh      # REBOOTS the appliance, then proves
                                                # it came back with no operator action
```

`phase7-final-reboot.sh` really reboots the machine and verifies the kernel boot
id changed — a service restart is not reboot evidence. It waits for the
appliance to converge to **serving** (not merely `active`, since a unit can be
active while the thing it serves does not answer) and repairs nothing: if the
appliance needs a human to come back, the run fails rather than hiding it.

---

## 29. Audit & monitoring

- **Every** privileged action in Central and on the appliance is written to an
  **audit log** with actor, action, target and reason. Delete/rotate/restart
  actions require a reason that is recorded.
- Central aggregates fleet **service health** and **security** telemetry over an
  mTLS NATS channel; the Dashboard and Fleet pages summarize it.
- Legacy `subscription.*` audit action names may appear on **historical** rows;
  no new normal-workflow action uses them.

---

## 30. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Appliance never appears in Central | No WAN/internet, or `SCD_AUTO_REGISTER=false` | Fix WAN (§5); confirm auto-register, or use a token (§34) |
| Registration refused (403) + security alert | Clone/hardware-reuse protection | Decommission the old record (§25), then retry |
| Stuck at Pending activation | Not activated yet | Activate it (§7) |
| Stuck activating / no license | CSR/license not yet pulled, or Central briefly unreachable | Wait; check Diagnostics; confirm Central reachability |
| Guests denied, License shows Expired | Past valid-until + grace | Renew the license (§20) |
| Guests denied, `LICENSE_CAPACITY_REACHED` | At appliance-wide concurrent capacity | Wait for a slot, or raise Max Concurrent Online Guests (§20) |
| Guest denied, `MAX_DEVICES_REACHED` | The voucher/account is at its **plan max devices** | Disconnect a device (Hotel Admin → Guest accounts / Sessions), raise the plan's Max devices, or use another credential |
| A device's reconnect seems to "use up" a slot | It doesn't — same credential + same device reuses its slot | Confirm the extra slot is a *different* device (MAC); check active devices on the account/voucher Details |
| Guest login says "Invalid username or password" for a known-good account | Disabled, outside valid-from/until, or locked after failed attempts | Check enabled + validity; reset the password (clears the lockout); short-wait if throttled |
| Guest login says "Too many attempts" | Brute-force throttle tripped (username+IP/device or endpoint-wide) | Wait ~1 minute and retry |
| Lost a guest password | Passwords are shown once and never stored in plaintext | Set a new password (Guest accounts → Password); it's shown once again |
| Can't change a voucher's plan | Voucher is revoked/expired/exhausted, or has a live session | Only unused/idle vouchers can be repointed; disconnect the session first |
| Guest keeps re-using an "expired" voucher for more time | Voucher duration is a **validity window** from first use; it doesn't reset | Expected: once the window closes the voucher shows **Expired** and re-login is refused; a reconnect only gets the remaining window. Issue a new voucher for more access |
| A voucher expired "too fast" with two devices | The window is wall-clock from first activation, **not** per-device | By design — a second device shares the same window, it doesn't add time. Give each guest their own voucher, or use a longer plan |
| Guests denied, state Unlicensed | No valid license (fail-closed) | Activate / import license (§7, §34) |
| Can't create plans/vouchers/accounts | License not Active | Renew/activate |
| Portal doesn't auto-pop | DHCP option 114 / walled garden | Verify network settings and walled garden (§13, §17) |
| Locked out after a WAN/LAN change | Confirmation window elapsed | It auto-rolled-back; reconnect to the old IP (§5) |
| "Cloud validation stale" warning | Central unreachable | Informational only; guests keep working (§22) |
| WAN-MAC mismatch warning | WAN NIC changed | Rebind MAC (§23) |

---

## 31. Go-live checklist

- [ ] Appliance registered and **Activated** (Central shows Active; Hotel Admin →
      License shows **Active**, correct **Max online guests** and **Valid until**).
- [ ] WAN/LAN correct and confirmed (no pending rollback).
- [ ] Guest network(s) / VLAN(s) created, applied and confirmed.
- [ ] DHCP pools, DNS, NAT and client isolation set per network.
- [ ] Captive portal reachable at `http://{gateway}:8380`; option 114 popping the
      portal.
- [ ] Auth method(s) configured and tested; integrations healthy.
- [ ] Walled garden covers portal/payment/OAuth hosts.
- [ ] Access plans + voucher batches ready (if using vouchers).
- [ ] **Real guest acceptance test passed** on each VLAN (§18).
- [ ] Branding correct per network.
- [ ] Operators created with least-privilege roles.

---

## 32. Day-2 operations checklist

| Task | Where |
|---|---|
| Watch fleet health & alerts | Central → Dashboard / Fleet / Security alerts |
| Renew a license before expiry | Central → Licenses (§20) |
| Raise/lower concurrent capacity | Central → re-issue license (§10, §20) |
| Add/replace an appliance | Central → Replace (§23) |
| Rebind after a NIC swap | Central → Rebind MAC (§23) |
| Rotate a cert | Hotel Admin → TLS certificate (§27) |
| Issue voucher batches | Hotel Admin → Voucher batches (§15) |
| Add a guest VLAN | Hotel Admin → Guest networks (§11) |
| Check backups | Central → Backup health (§28) |
| Review audit log | Central / Hotel Admin → Audit (§29) |
| Retire hardware | Central → Decommission/Delete (§25, §26) |

---

## 33. Terminology (canonical operator terms)

Use these operator-facing terms consistently. Internal/technical names in the
right column are kept in code/URLs where changing them would create migration
risk, but should not be shown to operators as the primary term.

| Concept | Canonical operator term | Internal / technical name(s) |
|---|---|---|
| Paying organization | **Customer** | tenant, `tenant_id`, `/tenants` |
| Physical property | **Site** | site |
| On-site gateway | **Appliance** | appliance |
| Bring an appliance online (normal) | **Activate / Activation** (zero-touch) | onboarding, claim, register |
| Manual/offline install method | **Enrollment token (advanced)** | bootstrap token |
| The entitlement | **Signed appliance license** | license (NOT plan/subscription) |
| License states | **Active / GracePeriod / Expired / Suspended / Revoked / Unlicensed** | `Restricted` = legacy pre-v3 only |
| Capacity | **Max concurrent online guests** (appliance-wide) | `max_concurrent_online_guests` |
| Per-voucher device limit | **Max devices** (on an access plan) | plan max devices |
| Limit-exceeded error | **License limit reached** | `limit_exceeded` |
| Live guest count | **Online guests / Active sessions** | `current_online_guests` |
| Appliance↔Central link | **Connected / Disconnected** | reachable, cloud_stale |
| Guest pricing/policy product | **Access plan** | guest access plan |
| Pre-login allowlist | **Walled garden** | walled garden |
| Portal | **Captive portal / Landing page** | portald |

**Retired terms — do not present as current:** Plan, Subscription, Commercial
plan, Trial, plan limits. The signed appliance license is the only entitlement.

---

## 34. Advanced / exceptional: enrollment tokens & offline activation

These are **not** the normal install path. Use only when zero-touch cannot apply.

**Enrollment token** — for pre-registering a box, or when
`SCD_AUTO_REGISTER=false`, or an installer must type a code:

1. Central → **Appliances** → **Enrollment token** → optionally lock it to the
   box's **Serial** → **Mint token** (shown once — copy it).
2. On the box, Hotel Admin → **Setup / Activation** → paste the **enrollment
   code** + confirm the **Serial** → **Connect**.
3. Continue with **Activation** in Central exactly as in §7.

**Offline activation** — for sites with no cloud path:

1. Hotel Admin → **License** → copy the **StayConnect Serial Number** and **WAN
   MAC** and send them to StayConnect.
2. StayConnect returns a signed `.license` file bound to that exact serial + WAN
   MAC.
3. Hotel Admin → **License** → **Offline activation** → **Upload license file**.
   The box verifies the file is bound to this exact hardware before accepting it.

Both paths converge to the same **Active** state and the same license model as
zero-touch; only the bootstrap differs.
