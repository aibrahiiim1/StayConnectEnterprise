# StayConnect IAM — Context Handoff

<!-- BEGIN GENERATED PROJECT STATE — DO NOT EDIT -->
<!-- source: governance/project-state.json (schema 1.0.0) @ transition T0058 -->
**Current phase:** 6 — Guest device self-service; optional AGGREGATE_ONLINE_TIME
**Current activity:** `PHASE_6_IMPLEMENTATION_IN_PROGRESS_DARK`
**Phase status:** 0 FINAL_CLOSED · 1A **ACCEPTED_AND_CLOSED** (DARK, NOT CUT OVER) · 1B ACCEPTED_AND_CLOSED (DARK — accepted & closed; no cutover; no production iam_v2 use) · 2 ACCEPTED_AND_CLOSED · 3 ACCEPTED_AND_CLOSED · 4 ACCEPTED_AND_CLOSED · 5 ACCEPTED_AND_CLOSED · 6 IN_PROGRESS · 7 NOT_STARTED
**Phase 1A maturity:** ACCEPTED_AND_CLOSED — SCRATCH_VERIFIED + OFFLINE_REAL_SCHEMA_COMPATIBILITY_VERIFIED + PRODUCTION_LIVE_DARK_CREATED_AND_VERIFIED — DARK, NOT CUT OVER
**iam_v2:** 68 tables, 0 rows, dark; no service routed; no data migration; legacy public schema is the currently CONFIGURED authentication/routing baseline. PRE-LIVE (D24): no real hotel guest or staff depends on either path for live service yet.
**Single next authorized action:** Continue Phase-6 milestone M3 under D25 on branch phase/6-device-selfservice-and-time-modes -- the AGGREGATE_ONLINE_TIME vertical slice (aggregate online-time budget plus an outer hard-validity window, shared device-minute semantics, accounting eligibility restricted to sessions in state 'active' only, atomic terminal transition at the first applicable condition), delivered DARK, followed by M4 hardening and the DEVELOPMENT-appliance LIVE-DARK acceptance candidate, stopping at the acceptance boundary with one pull request open and unmerged for a separate Product-Owner decision.
**Governance:** current state is generated from `governance/project-state.json`; do not edit this block by hand. Latest accepted PO decision: `D25`.
<!-- END GENERATED PROJECT STATE -->


Operational handoff for a future agent or new session working on the Internet Access Management (IAM) redesign. The authoritative design is [StayConnect-IAM-Phase0-Contract.md](StayConnect-IAM-Phase0-Contract.md); the live spike record is [Protel-FIAS-Phase0-Spike.md](Protel-FIAS-Phase0-Spike.md).

**Current synchronized documentation baseline:** the Phase-1A live-dark reconciliation commit (see git log; supersedes `79bf3e8`/`22a2e15`). *(Historical Phase-0 finalization provenance only: contract `ffe2200`, synchronized handoff `6b4721d` — not current.)*

## Current Stage

**Authoritative current phase/activity/maturity/next-action = the GENERATED PROJECT STATE block at the top of this file** (rendered from `governance/project-state.json`). The Phase 1B plan is [StayConnect-IAM-Phase1B-Plan.md](StayConnect-IAM-Phase1B-Plan.md); it has been **implemented, live-dark deployed (transition T0010), and formally Product-Owner ACCEPTED AND CLOSED at DARK maturity (transition T0011, decision D11)** — including the mandatory least-privilege / superuser-elimination prerequisite (Gate P), which is COMPLETE and reboot-verified — see Phase 1B live-dark acceptance. No cutover; all dark features remain OFF. **HISTORICAL, AS OF PHASE-2 CLOSURE (2026-07-18) — NOT the current activity:** Phase 2 (Commercial Packages) was authorized under D12/T0012, implemented, live-dark deployed + reboot-verified (T0013), and Product-Owner ACCEPTED_AND_CLOSED at verified DARK maturity (D13/T0014); PR #4 is MERGED and CLOSED (merge commit `fe6a0d1`). **For the current phase, activity and next action read the generated PROJECT STATE block at the top of this file — it is the only current-state surface.** — the [Phase 2 plan](StayConnect-IAM-Phase2-Plan.md), [acceptance record](StayConnect-IAM-Phase2-Live-Dark-Acceptance.md) and [final report](StayConnect-IAM-Phase2-Final-Report.md) are authoritative. This section carries no separate current-state description.

## Current Status (evidence & context — not a current-state source)

- **Contract status: `FINAL` — Phase 0 CLOSED** *(2026-07-16, explicit Product-Owner approval; previously READY_FOR_FINAL_OWNER_APPROVAL, before that CONDITIONALLY FROZEN).* *(Historical: at Phase-0 close, FINAL closed the architecture without by itself unlocking implementation, and Phase 1A **planning** was then the only authorized activity pending separate plan approval — that gate is now satisfied and does not describe current status; see the generated block for current state.)*
- The live Protel FIAS Phase-0 spike is **done**; results are merged into contract §9b/§9c/§9d.
- The Phase 1A execution plan ([StayConnect-IAM-Phase1A-Plan.md](StayConnect-IAM-Phase1A-Plan.md)) is **SCRATCH_IMPLEMENTED + SCRATCH_VERIFIED + OFFLINE_REAL_SCHEMA_COMPATIBILITY_VERIFIED + PRODUCTION_LIVE_DARK_CREATED_AND_VERIFIED (2026-07-16)** — **formally ACCEPTED/CLOSED at this DARK maturity (2026-07-16); NOT deployed, NOT cut over, NOT a user-facing/authority-switch system, NO IAM data migration, NO Phase 1B implementation**. The isolated `iam_v2` schema (49 tables, fingerprint `bd75026f`, 0 rows) now exists **dark** in production `stayconnect_site` (primary; PG 16.3): no service reads/writes it, no DSN/`search_path` change, public **structural** fingerprint unchanged (`d86ca4c6` before==after; public *rows* change under CONTROLLED TESTING traffic, not real hotel guest traffic (PRE-LIVE, D24) — the structural fingerprint is the invariant, not the row count), services active. Additive + reversible (rollback proven). Deviation recorded: services connect as superuser `stayconnect`, so darkness rests on zero code refs + `search_path` (both verified), not privilege grants — this is a **mandatory Phase-1B prerequisite** (least-privilege service roles + credential rotation before any routing). **Phase 1B UPDATE — deployed T0010 (2026-07-17), ACCEPTED AND CLOSED at DARK maturity via T0011/D11: this prerequisite is COMPLETE — all four site-DB daemons (scd/edged/acctd/netd) run under least-privilege `svc_*` roles (NOSUPERUSER, SCRAM), reboot-verified; zero `iam_v2` privilege retained. See [Phase 1B live-dark acceptance. No cutover; dark features OFF.]** See [Live-Dark Acceptance record](StayConnect-IAM-Phase1A-Live-Dark-Acceptance.md) (18/18) + authoritative read-only re-verification `iam_v2_scratch/review/prod/PROD_LIVE_DARK_EVIDENCE_V2.txt` (the earlier `PROD_LIVE_DARK_EVIDENCE.txt` is superseded/erroneous). Evidence + review bundle in `iam_v2_scratch/` (`EVIDENCE.txt`, `review/`): MG-0…MG-9 (49 `iam_v2` tables) + engine; **99/99 PASS** — Core 42, Extra 11, allowlist-guard 12, role/least-privilege 20 (objects owned by `iam_v2_owner`, service roles+PUBLIC denied), migration idempotency 5 (apply-twice no-op + catalog equality), offline real-schema compatibility 9 (identical `iam_v2` catalog on the committed real platform chain `0001..0006`). Contract-to-implementation fidelity matrix: 0 missing constraint/FK/trigger/index. Disposable Docker Postgres, allowlist-guarded; N/A-SCRATCH/DEFERRED items never counted PASS. Phase 1A is formally accepted/CLOSED at this maturity. *(HISTORICAL tail, superseded: at the time this line was written the next action was PO approval of the Phase 1B plan.)* **HISTORICAL, AS OF PHASE-2 CLOSURE (2026-07-18) — NOT the current activity:** Phase 1B was ACCEPTED_AND_CLOSED (D11/T0011) and Phase 2 ACCEPTED_AND_CLOSED at DARK maturity (D13/T0014), MERGED to master (merge commit `fe6a0d1`); at that time cutover, IAM data migration, legacy cleanup and Phase 3 each remained under separate future authorization. *(Phases 3 and 4 have since been accepted and closed — Phase 3 at DARK maturity D16/T0024 and merged D17/T0025, Phase 4 at LIVE-DARK maturity D19/T0044.)* **The current phase, activity and next action are the generated PROJECT STATE block at the top of this file.** Isolation is an **isolated `iam_v2` schema** inside the existing site DB (dark; rollback = leave dark / drop schema; a separate gated `search_path` cutover — **not** a whole-DB standby swap). Row-level locks preferred over advisory (verified admission namespaces `LN_DEVICE_SLOT`=11 / `LN_CAPACITY`=7 from `session.go`); cutover is an **atomic complete-domain switch of all IAM services** (never per-flow/per-service) with **two rollback boundaries** (safe flip-back only *before* the first production write to `iam_v2`; after it, forward-fix / reconcile-before-return); reversal stays `capability=false` (no executable reversal built in 1A); Stripe FK deferred (no platform anchor exists). **Folio amendment — APPROVED & in force (2026-07-16):** FINAL contract §4.1 amended to `folio_identity_strategy NOT NULL DEFAULT 'UNSET'` (4-value CHECK). `UNSET` is fail-closed — read-only ingestion/lookup/auth allowed, **every financial CHARGE blocked before outbox/`P#`/transmission** until property onboarding records a concrete strategy in a **new** revision. `UNSET` is the only unset sentinel (`UNKNOWN` stays a Posting state). No open folio item remains.
- **HISTORICAL (Phase-0/1A-era statement — NO LONGER CURRENT).** *At the time this line was written no redesign feature implementation had started.* **HISTORICAL replacement, AS OF PHASE-2 CLOSURE (2026-07-18):** Phase 1A + Phase 1B were ACCEPTED_AND_CLOSED at DARK maturity, and Phase 2 (Commercial Packages) ACCEPTED_AND_CLOSED at verified DARK maturity (D13/T0014), all flags OFF; PR #4 MERGED and CLOSED (merge commit `fe6a0d1`). **The current state is the generated PROJECT STATE block at the top of this file.** The deployed voucher/guest-account/max-devices system remains a separate prior delivery, DEPLOYED AND UNTOUCHED. PRE-LIVE (D24/T0056): it is not serving real hotel guests today -- it is the configured baseline in a system under active development and controlled testing.

## Proven Phase-0 Scope (Tier 1 — the finalization basis)

Measured live and merged into the contract. Covers **only** what is listed; do **not** generalize the single Hotel ID 3 debit to other properties/interfaces, sharers, multi-folio, no-post, or error `AS` statuses.

- both Protel PMS endpoints are **reachable**;
- each PMS Interface has an **independent namespace** (identical room numbers across interfaces never collide);
- FIAS **framing and `LS`/`LD`/`LR`/`LA` startup** are verified (client sends `LS/LD/LR` immediately on connect, acks incoming `LS`/`LA` with a bare `LA|`; do not gate on a client-side "reach LA first" milestone);
- **`GI`/`GC`/`GO`** guest feed is verified (plus read-only `DR` resync);
- **`RN` + `G#` are mandatory** for Guest-Folio Posting (an `RN`-only `ASOK` is not proof);
- **`PS`/`PA` financial wire behavior is production-grounded** (`PS` field order `RN,G#,TA,PT,SO,CT,P#,WS`; `PA` fields `RN,AS,P#,CT`; `AS ∈ {OK,NG,NA,NP,NR,RY,UR}`);
- **Coral Sea Holiday Village / Hotel ID 3** completed **one live controlled Debit** (USD 1.00, `TA100`);
- **`PA ASOK` matched using PMS Interface + `P#`** (never by Room Number);
- Front Office **verified the correct Guest Folio**;
- **`SO=WIFI` revenue mapping** was verified;
- **manual correction** was completed;
- the **Folio returned to its original balance**;
- the Protel Interface has **one active-client slot** (single-client Socket Server);
- **`P#` is a protocol-attempt reference, not business idempotency**.

## Tier 2 — Per-Property Financial Onboarding (deployment gate, NOT a Phase-0 blocker)

Before financial Posting is enabled for **any** Property, that Property must independently validate:

- PMS Interface **currency and exponent**;
- **Package currency compatibility**;
- **`SO=WIFI` revenue mapping**;
- **`RN` + `G#` Folio targeting**;
- **one controlled Debit**;
- **actual Folio placement**;
- **approved correction and net-zero cleanup**.

**Coral Sea Aqua Club / Hotel ID 2 (`120.0.0.15:5001`)** is: **read-only FIAS capable**; **financially unapproved**; **pending its own property onboarding test**. It does **not** block architecture finalization.

## v1 Limitations (deferred; recorded in contract §9d)

- `programmatic_reversal = false`;
- corrections use an **audited manual Front Office process**;
- **no implicit FX conversion** for PMS-settled Packages;
- **Package currency must match the pinned PMS Interface currency**;
- **physical traffic accounting still requires live implementation acceptance** (non-zero real-device usage → accounting), unprovable at Phase 0.

## Tier 3 — Post-Implementation Acceptance Gates (binding; testable only after the components exist)

- **Gate 3C** — after the **Posting Engine** exists (`posting_attempts`/`posting_attempt_events`, `pms_interface_pnumber_seq`, Manual-Review): transmitted request with no matching `PA` becomes **UNKNOWN**; **no automatic retry**; **no auto-allocated second `P#`**; Manual-Review workflow; external Folio reconciliation; audited `CONFIRM_POSTED`/`RETRY_APPROVED`/`ABANDON`; **duplicate prevention**.
- **Gate 3D** — after the **PMS/Entitlement** components exist (Stay/Event persistence, Checkout handler, Post-Stay profile, Checkout-Grace Purchase+Entitlement, session reassignment, accounting cutoff, idempotent processing): **Checkout** (healthy-link / link-down / delayed), **stale occupancy** refusal, **Checkout Grace**, **session reassignment**, **accounting cutoff** at the effective checkout timestamp, and **idempotency** — with no intentional guest disconnect or re-authentication.

## Non-Negotiable Product Decisions (compact)

1. **No guest-facing PMS selector** — automatic STRICT backend Multi-PMS resolution on the complete outcome vector; unavailable/stale candidates block auth; unmapped guest networks fail closed; uniform time-padded non-success responses.
2. **Room Number is evidence, never identity or financial ownership.** Every Stay, Folio, Event, Purchase, and Posting is pinned to exactly one PMS Interface namespace. Sharers (two stays, one room) are legal.
3. **Mandatory Seamless Checkout Grace** (site-level hidden system package): eligible checked-out guests atomically superseded onto grace; sessions rebind with zero nft churn, no re-auth; over-limit devices grandfathered; no future room posting; emergency fallback if config corrupt.
4. **One live data-plane Entitlement per subject**; changes are atomic same-subject supersessions; cross-PMS movement via typed cycle-safe `entitlement_transfers`.
5. **Stable tenant-wide Guest Principals** for OTP/social keyed by verified factors; **MAC addresses identify Devices only, never people**.
6. **Immutable revisions everywhere** (plans, packages, mappings, interface configs, PMS secret generations); purchases/postings pin exact revisions.
7. **Voucher codes HMAC-indexed + AEAD-encrypted** (recoverable value + last4); reveal/export re-auth + audit; single-redemption.
8. **One-time Auth Contexts and Offer Quotes**, consumed atomically with Purchase creation. **Sessions created only after Entitlement grant.**
9. **Idempotent accounting** via per-session watermarks + append-only ledger + monotonic counters; audited adjustments are the only decrease.
10. **Financial safety:** purchase → settlement → posting/payment separation; postings pin interface + both revisions + secret generation + folio + exact settlement/purchase pair; per-interface outbox lanes; **UNKNOWN never auto-retries**; FINANCIAL_RECOVERY_MODE after restore; five-action manual-review governance; ISO-4217 minor-unit money.
11. **Compliance archive with verified receipt before cross-customer purge**; tenant DEK crypto-shred; fail-closed transition.
12. **Supported-restore limitation:** exactly-once FIAS posting is guaranteed only under manifest-signed restore workflows.
13. **No feature implementation until the contract is approved FINAL.**

## Roadmap (completed / current / future)

1. **Phase 1A — clean-slate IAM core + persistence.** Scratch verification: **done**. Offline real-schema compatibility: **done**. **Production live-dark creation + acceptance: DONE (2026-07-16, 18/18).** ← current maturity.
2. Phase 1B — credential/portal integration, initially dark/flagged. *(not started)*
3. Phase 2 — packages, quotes, non-financial purchases.
4. Phase 3 — stays, events, STRICT multi-PMS resolution.
5. Phase 4 — financial Posting + payment execution with UNKNOWN/manual-review safety.
6. Phase 5 — Checkout Grace, post-stay, cross-PMS transfer.
7. Phase 6 — guest self-service + remaining IAM capabilities.
8. Full-domain implementation + acceptance of every supported IAM path.
9. Separately-approved **atomic complete-domain cutover**.
10. Post-cutover soak, reconciliation, separately-approved legacy cleanup.

## Next Authorized Step

**The single authoritative current next action is the GENERATED PROJECT STATE block at the top of this file.** As of the current state that is: **no further Phase-4 action is authorized** — Phase 4 is accepted, closed and **merged**. PR #12 was merged into `master` on 2026-08-14 under decision **D20** (transition **T0048**), merge commit `210154b5ba72178bae715e7c8e4a1398ca629257`; the merge introduced no content and deployed nothing. Phases 0, 1A, 1B, 2, 3 and 4 are all **ACCEPTED_AND_CLOSED** — Phase 3 at verified DARK maturity (D16/T0024) and **MERGED** to master (D17/T0025, merge commit `8a7230a7`), Phase 4 at verified **LIVE-DARK / NO-FINANCIAL-TRAFFIC** maturity (D19/T0044) and Phase 4 MERGED to master on 2026-08-14 under the separate Product-Owner merge decision **D20** (transition **T0048**), merge commit `210154b5ba72178bae715e7c8e4a1398ca629257`. Every Phase-3 and Phase-4 flag is OFF; no PMS financial posting, no IAM-v2 cutover and no paid access is authorized. **That sentence described the state at Phase-4 closure and is kept as the record of it.** Phase 5 has since been ACCEPTED_AND_CLOSED and MERGED. Phase 6 is AUTHORIZED and IN PROGRESS under decision D25 (transition T0057), with every Phase-6 flag OFF on every environment. No Phase-7 work is authorized. The generated PROJECT STATE block at the top of this file is the only current-state surface.

*HISTORICAL ladder (superseded — retained for provenance; NOT the current next action):*
1. ~~Product-Owner approval or rejection of the Phase 1B plan.~~ **DONE** — Phase 1B plan approved, implemented, and ACCEPTED_AND_CLOSED at DARK maturity (D11/T0011); PR #2 merged.
2. ~~Phase 1B implementation under its own PO authorization.~~ **DONE** (dark; least-privilege Gate P complete + reboot-verified).
3. ~~Product-Owner acceptance of Phase 2 (Commercial Packages) at DARK maturity.~~ **DONE** — accepted and closed (D13/T0014); PR #4 MERGED and CLOSED (merge commit `fe6a0d1`); post-merge Governance CI green.
4. ~~Product-Owner authorization of Phase 3.~~ **DONE** — Phase 3 authorized (D14/T0015), accepted and closed at DARK maturity (D16/T0024) and merged (D17/T0025).
5. ~~Product-Owner authorization of Phase 4.~~ **DONE** — Phase 4 authorized (D18/T0029), deployed live-DARK (T0043) and **accepted and closed at verified LIVE-DARK / NO-FINANCIAL-TRAFFIC maturity** (D19/T0044). Guest-visible activation / IAM-v2 cutover / DSN-`search_path` routing / IAM data migration / legacy cleanup / real financial traffic / **Phase 5, 6 and 7** remain **separately gated** future steps, each needing its own PO approval.

Per-property onboarding (Tier 2, incl. Aqua Club) and post-implementation acceptance (Tier 3 / Gates 3C, 3D) are **not** Phase-0 finalization blockers; they carry forward as, respectively, a deployment prerequisite and binding acceptance requirements.

## Forbidden Until Separately Authorized (Phase 1B / cutover / deployment)

*(Phase 1A is implemented to production live-dark. The following remain forbidden until each is explicitly and separately authorized — approval of Phase 1A does **not** authorize any of them.)*

- further schema DDL for this domain **beyond the created dark `iam_v2`** (e.g. cutover/data-migration DDL);
- routing any service to `iam_v2`, DSN/`search_path` change, dual-write, or IAM data migration;
- feature code;
- production connector development;
- portal/admin-UI work;
- PMS production configuration changes;
- `pms_providers` creation;
- live Posting (no further PMS financial test without separate explicit authorization);
- network scanning;
- deployment of IAM-redesign artifacts.

## Useful Environment Facts

- Appliance: `172.21.60.23` (SSH as root, key auth), code at `/opt/stayconnect`, Postgres in container `stayconnect-pg`, site DB `stayconnect_site` (+ an isolated second-site **test** DB `stayconnect_site_b` used for isolation tests — **not** a replication standby).
- Central Control Plane: `150.0.0.252` — do not touch for this work.
- PMS Interfaces (owner-attested): **Hotel ID 3** Coral Sea Holiday Village `150.0.0.18:5003` (financially validated — one debit, Gate 3A PASS); **Hotel ID 2** Coral Sea Aqua Club `120.0.0.15:5001` (read-only capable, financially unapproved). No `IfcAuthKey` on either interface. **Do not discover PMS systems by network scanning.**
- Repo: `d:\WebProjects\StayConnectEnterprise`. Existing FIAS parsing/framing lives in `data-plane/internal/pms/` (lookup-only; no posting code exists anywhere yet).
- The currently deployed production IAM (vouchers/guest accounts/plans, commits `8a1f882`/`0cca51b` era) stays operational — it is the sole authority throughout Phase 1B (which is DARK, not a cutover) and until the later **atomic complete-domain cutover** (only after Phases 2–6 and full-domain acceptance; far in the future, separately gated).
- **Appliance topology (approved, permanent): exactly two physical NICs — WAN and LAN.** WAN is **also the management interface** (Hotel Admin/SSH/outbound sync); LAN carries guest connectivity and guest VLAN/trunk behavior. There is **no** separate physical management NIC and **no** approved third HA-sync NIC. `SYSTEM_OVERVIEW.md` and the operations manual already reflect this (WAN=`ens160`, LAN=`ens192`). The older `DEPLOYMENT_APPLIANCE.md`/`TARGET_ARCHITECTURE.md` three-interface (separate mgmt + optional `hasync`) wording is **superseded** by this two-NIC rule.

## Open Architecture Decisions (unresolved)

- **HA synchronization transport under the two-NIC rule (still OPEN).** The prior HA design (VRRP/conntrackd/nft-set replication/Postgres streaming replication) assumed a **dedicated third `hasync` NIC**, which is now superseded. The exact HA-sync transport over a two-NIC (WAN+LAN) appliance is **not designed, implemented, or accepted** — this is an **OPEN architecture decision**. **Single-appliance local-first/offline operation is current and supported; HA failover under the final two-NIC architecture is NOT.** Do **not** claim any WAN/LAN HA failover, conntrack/nft replication, or Postgres streaming replication is available.
- *(Resolved 2026-07-16: the `folio_identity_strategy` fail-closed amendment was Product-Owner-approved and applied to the FINAL contract §4.1 — no longer an open item.)*

## Permanent Rules (mandatory)

- **[Zero Stale Leftovers](ZERO_STALE_LEFTOVERS_RULE.md)** — after every milestone/decision/implementation change, no stale/superseded/contradictory/partially-updated artifact may remain anywhere (docs, code, config, exports, manifests); run the repo-wide stale scan + `tools/validate-project-state.sh`, prove zero current-state contradictions, and confirm `ZERO_STALE_LEFTOVERS = PASS` before declaring a milestone complete. A lower section does not fix a stale statement earlier in the same file; a banner does not excuse contradictory current-state content.
- **Documentation synchronization** — the latest PO-approved contract + verified execution evidence override all older docs/chats; all directly-related sources must state one consistent current status, maturity, limitations, authoritative commits, remaining blockers, and the **single** next authorized action. Old content survives only when explicitly labeled HISTORICAL/SUPERSEDED and cannot be mistaken for current.
